import 'package:flutter/material.dart';
// NOUVEL IMPORT NÉCESSAIRE pour initializeDateFormatting
import 'package:intl/date_symbol_data_local.dart';

// Vos imports d'écrans
import 'screens/login.dart';
import 'screens/home.dart';
import 'screens/upload.dart';    // Contient UploadApp qui mène à DocumentTypeSelectionScreen
import 'screens/documents.dart'; // Contient UploadHistoryPage
import 'screens/profile.dart';   // Contient ProfilePage

// La fonction principale qui lance votre application
void main() async { // MODIFIÉ: main() doit être async

  // Message de débogage pour voir quand main() commence
  print("DEBUG DANS MAIN: La fonction main() commence.");

  // MODIFIÉ: Cette ligne est importante avant d'utiliser des fonctions 'await' avant runApp
  WidgetsFlutterBinding.ensureInitialized();
  print("DEBUG DANS MAIN: WidgetsFlutterBinding est initialisé.");

  try {
    // MODIFIÉ: C'est l'appel crucial : "Dis à Flutter de préparer les formats de date français"
    await initializeDateFormatting('fr_FR', null);
    // Message de débogage pour confirmer que l'initialisation a été appelée et s'est terminée
    print("DEBUG DANS MAIN: initializeDateFormatting pour 'fr_FR' a été appelé et s'est terminé SANS ERREUR.");
  } catch (e) {
    // Si une erreur se produit PENDANT l'initialisation, on la verra ici
    print("DEBUG DANS MAIN: ERREUR pendant initializeDateFormatting: $e");
  }

  // Lance votre application
  runApp(const MyApp()); // MyApp peut probablement rester const si son constructeur est const
  print("DEBUG DANS MAIN: runApp() a été appelé.");
}

// Le widget principal de votre application
class MyApp extends StatelessWidget {
  const MyApp({super.key}); // Ce constructeur est const

  @override
  Widget build(BuildContext context) {
    // Message de débogage pour voir quand MyApp.build() est appelé
    print("DEBUG DANS MYAPP: La méthode build() de MyApp est appelée.");
    return MaterialApp(
      title: 'ComptaLink',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 0,
          titleTextStyle: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold)
        )
      ),
      initialRoute: '/',
      routes: {
        // MODIFIÉ: 'const' supprimé devant les constructeurs de vos écrans
        // s'ils ne sont pas eux-mêmes des constructeurs const.
        '/': (context) => LoginScreen(),
        '/login': (context) => LoginScreen(),
        '/home': (context) => DashboardScreen(),
        '/upload': (context) => UploadApp(),
        '/documents': (context) => UploadHistoryPage(),
        '/profile': (context) => ProfilePage(),
      },
    );
  }
  
}