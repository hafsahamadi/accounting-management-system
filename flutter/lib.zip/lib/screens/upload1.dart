import 'package:flutter/material.dart';
import 'dart:io';
import 'package:dio/dio.dart';

Future<void> uploadDocument(String token, String categorie, String filePath) async {
  var dio = Dio();

  FormData formData = FormData.fromMap({
    'categorie': categorie,
    'document': await MultipartFile.fromFile(filePath, filename: 'document.pdf'),
  });

  try {
    var response = await dio.post(
      'http://192.168.1.10/api/documents',
      options: Options(
        headers: {
          'Authorization': 'Bearer $token',
        },
      ),
      data: formData,
    );

    if (response.statusCode == 200) {
      print('Document téléchargé avec succès');
    } else {
      print('Erreur : ${response.statusCode}');
    }
  } catch (e) {
    print('Erreur de téléchargement : $e');
  }
}



class UploadApp extends StatelessWidget {
  const UploadApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const DocumentTypeSelectionScreen(); // pas de MaterialApp ici
  }
}

// Page principale de sélection du type de document
class DocumentTypeSelectionScreen extends StatelessWidget {
  const DocumentTypeSelectionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Télécharger Document',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 24),
            const Text(
              'Sélectionnez le type de document',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 40),
            _buildDocumentTypeButton(
              context,
              'Bon de livraison',
              Icons.local_shipping_outlined,
              () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const DeliveryNoteUploadScreen(),
                ),
              ),
            ),
            const SizedBox(height: 24),
            _buildDocumentTypeButton(
              context,
              'Facture',
              Icons.receipt_long_outlined,
              () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const InvoiceTypeSelectionScreen(),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomNavigationBar(context, 1),
    );
  }

  Widget _buildDocumentTypeButton(
    BuildContext context,
    String title,
    IconData icon,
    VoidCallback onPressed,
  ) {
    return SizedBox(
      width: double.infinity,
      height: 100,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: const Color(0xFF2196F3),
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(color: Colors.grey.shade300),
          ),
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        ),
        child: Row(
          children: [
            Icon(icon, size: 40, color: const Color(0xFF2196F3)),
            const SizedBox(width: 20),
            Text(
              title,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w500,
                color: Colors.black87,
              ),
            ),
            const Spacer(),
            const Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 16),
          ],
        ),
      ),
    );
  }
}

// Page de sélection du type de facture
class InvoiceTypeSelectionScreen extends StatelessWidget {
  const InvoiceTypeSelectionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Type de Facture',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 24),
            const Text(
              'Sélectionnez le type de facture',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 40),
            _buildInvoiceTypeButton(
              context,
              'Facture d\'achat',
              Icons.shopping_cart_outlined,
              () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder:
                      (context) =>
                          InvoiceUploadScreen(invoiceType: 'Facture d\'achat'),
                ),
              ),
            ),
            const SizedBox(height: 24),
            _buildInvoiceTypeButton(
              context,
              'Facture de vente',
              Icons.point_of_sale_outlined,
              () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder:
                      (context) =>
                          InvoiceUploadScreen(invoiceType: 'Facture de vente'),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomNavigationBar(context, 1),
    );
  }

  Widget _buildInvoiceTypeButton(
    BuildContext context,
    String title,
    IconData icon,
    VoidCallback onPressed,
  ) {
    return SizedBox(
      width: double.infinity,
      height: 100,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: const Color(0xFF2196F3),
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(color: Colors.grey.shade300),
          ),
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        ),
        child: Row(
          children: [
            Icon(icon, size: 40, color: const Color(0xFF2196F3)),
            const SizedBox(width: 20),
            Text(
              title,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w500,
                color: Colors.black87,
              ),
            ),
            const Spacer(),
            const Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 16),
          ],
        ),
      ),
    );
  }
}

// Page d'upload pour bon de livraison
class DeliveryNoteUploadScreen extends StatefulWidget {
  const DeliveryNoteUploadScreen({Key? key}) : super(key: key);

  @override
  _DeliveryNoteUploadScreenState createState() =>
      _DeliveryNoteUploadScreenState();
}

class _DeliveryNoteUploadScreenState extends State<DeliveryNoteUploadScreen> {
  File? _mainDocument;
  File? _paymentProofDocument;
  bool _showPaymentProof = false;
  bool _isUploaded = false;
  bool _isLoading = false;

  // Simulation de sélection de document
  Future<void> _pickDocument(bool isMainDocument) async {
    // Simuler la sélection d'un fichier
    await Future.delayed(const Duration(milliseconds: 500));

    // Créer un fichier fictif pour la simulation
    setState(() {
      if (isMainDocument) {
        _mainDocument = File('bon_de_livraison.pdf');
      } else {
        _paymentProofDocument = File('justificatif_paiement.pdf');
      }
    });
  }

  // Soumission des documents
  Future<void> _submitDocuments() async {
    if (_mainDocument == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Veuillez sélectionner le bon de livraison'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    if (_showPaymentProof && _paymentProofDocument == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Veuillez sélectionner un justificatif de paiement'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    // Simuler le téléchargement
    await Future.delayed(const Duration(seconds: 2));

    setState(() {
      _isLoading = false;
      _isUploaded = true;
    });
  }

  void _resetForm() {
    setState(() {
      _mainDocument = null;
      _paymentProofDocument = null;
      _showPaymentProof = false;
      _isUploaded = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Bon de Livraison',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _isUploaded ? _buildSuccessScreen() : _buildUploadForm(),
      bottomNavigationBar: _buildBottomNavigationBar(context, 1),
    );
  }

  Widget _buildUploadForm() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            const Text(
              'Document du Bon de Livraison',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 8),
            const Text(
              'Veuillez télécharger votre bon de livraison (PDF ou image)',
              style: TextStyle(fontSize: 14, color: Colors.grey),
            ),
            const SizedBox(height: 16),
            _buildFileSelectionButton(
              'Sélectionner le Bon de Livraison',
              _mainDocument,
              () => _pickDocument(true),
            ),
            const SizedBox(height: 24),

            if (!_showPaymentProof)
              TextButton.icon(
                onPressed: () {
                  setState(() {
                    _showPaymentProof = true;
                  });
                },
                icon: const Icon(Icons.add_circle_outline),
                label: const Text('Ajouter un justificatif de paiement'),
                style: TextButton.styleFrom(
                  foregroundColor: const Color(0xFF2196F3),
                ),
              ),

            if (_showPaymentProof) ...[
              const Text(
                'Justificatif de Paiement',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
              ),
              const SizedBox(height: 8),
              const Text(
                'Ajoutez un justificatif de paiement (PDF ou image)',
                style: TextStyle(fontSize: 14, color: Colors.grey),
              ),
              const SizedBox(height: 16),
              _buildFileSelectionButton(
                'Sélectionner le Justificatif',
                _paymentProofDocument,
                () => _pickDocument(false),
              ),
              TextButton.icon(
                onPressed: () {
                  setState(() {
                    _showPaymentProof = false;
                    _paymentProofDocument = null;
                  });
                },
                icon: const Icon(Icons.remove_circle_outline),
                label: const Text('Supprimer le justificatif'),
                style: TextButton.styleFrom(foregroundColor: Colors.red),
              ),
            ],

            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: _isLoading ? null : _submitDocuments,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2196F3),
                minimumSize: const Size(double.infinity, 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                disabledBackgroundColor: Colors.grey[300],
              ),
              child:
                  _isLoading
                      ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                      : const Text(
                        'Soumettre',
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFileSelectionButton(
    String text,
    File? file,
    VoidCallback onPressed,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor:
                file != null
                    ? Colors.green[50]
                    : const Color.fromRGBO(233, 236, 239, 1),
            foregroundColor:
                file != null ? Colors.green[700] : Colors.grey[700],
            minimumSize: const Size(double.infinity, 50),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                file != null ? Icons.check_circle : Icons.upload_file,
                color: file != null ? Colors.green[700] : Colors.grey[700],
              ),
              const SizedBox(width: 8),
              Text(
                file != null ? 'Fichier sélectionné' : text,
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  color: file != null ? Colors.green[700] : Colors.grey[700],
                ),
              ),
            ],
          ),
        ),
        if (file != null)
          Padding(
            padding: const EdgeInsets.only(top: 8.0, left: 8.0),
            child: Row(
              children: [
                const Icon(Icons.attach_file, size: 16, color: Colors.grey),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    file.path.split('/').last,
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close, size: 16, color: Colors.grey),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  onPressed: () {
                    setState(() {
                      if (file == _mainDocument) {
                        _mainDocument = null;
                      } else if (file == _paymentProofDocument) {
                        _paymentProofDocument = null;
                      }
                    });
                  },
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildSuccessScreen() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.blue[50],
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.check_circle,
                color: Colors.blue[700],
                size: 80,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Document téléchargé avec succès!',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.blue[700],
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Text(
              _showPaymentProof && _paymentProofDocument != null
                  ? 'Votre bon de livraison et le justificatif de paiement ont été enregistrés.'
                  : 'Votre bon de livraison a été enregistré.',
              style: const TextStyle(fontSize: 16, color: Colors.black87),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                _resetForm();
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const DocumentTypeSelectionScreen(),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2196F3),
                minimumSize: const Size(200, 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text(
                'Télécharger un autre document',
                style: TextStyle(fontSize: 16, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Page d'upload pour facture (achat ou vente)
class InvoiceUploadScreen extends StatefulWidget {
  final String invoiceType;

  const InvoiceUploadScreen({Key? key, required this.invoiceType})
    : super(key: key);

  @override
  _InvoiceUploadScreenState createState() => _InvoiceUploadScreenState();
}

class _InvoiceUploadScreenState extends State<InvoiceUploadScreen> {
  File? _invoiceDocument;
  bool _isUploaded = false;
  bool _isLoading = false;

  // Simulation de sélection de document
  Future<void> _pickDocument() async {
    // Simuler la sélection d'un fichier
    await Future.delayed(const Duration(milliseconds: 500));

    // Créer un fichier fictif pour la simulation
    setState(() {
      _invoiceDocument = File('facture.pdf');
    });
  }

  // Soumission du document
  Future<void> _submitDocument() async {
    if (_invoiceDocument == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Veuillez sélectionner la ${widget.invoiceType.toLowerCase()}',
          ),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    // Simuler le téléchargement
    await Future.delayed(const Duration(seconds: 2));

    setState(() {
      _isLoading = false;
      _isUploaded = true;
    });
  }

  void _resetForm() {
    setState(() {
      _invoiceDocument = null;
      _isUploaded = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.invoiceType,
          style: const TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _isUploaded ? _buildSuccessScreen() : _buildUploadForm(),
      bottomNavigationBar: _buildBottomNavigationBar(context, 1),
    );
  }

  Widget _buildUploadForm() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            Text(
              'Document de ${widget.invoiceType}',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 8),
            Text(
              'Veuillez télécharger votre ${widget.invoiceType.toLowerCase()} (PDF ou image)',
              style: const TextStyle(fontSize: 14, color: Colors.grey),
            ),
            const SizedBox(height: 16),
            _buildFileSelectionButton(
              'Sélectionner la Facture',
              _invoiceDocument,
              _pickDocument,
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: _isLoading ? null : _submitDocument,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2196F3),
                minimumSize: const Size(double.infinity, 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                disabledBackgroundColor: Colors.grey[300],
              ),
              child:
                  _isLoading
                      ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                      : const Text(
                        'Soumettre',
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFileSelectionButton(
    String text,
    File? file,
    VoidCallback onPressed,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor:
                file != null
                    ? Colors.green[50]
                    : const Color.fromRGBO(233, 236, 239, 1),
            foregroundColor:
                file != null ? Colors.green[700] : Colors.grey[700],
            minimumSize: const Size(double.infinity, 50),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                file != null ? Icons.check_circle : Icons.upload_file,
                color: file != null ? Colors.green[700] : Colors.grey[700],
              ),
              const SizedBox(width: 8),
              Text(
                file != null ? 'Fichier sélectionné' : text,
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  color: file != null ? Colors.green[700] : Colors.grey[700],
                ),
              ),
            ],
          ),
        ),
        if (file != null)
          Padding(
            padding: const EdgeInsets.only(top: 8.0, left: 8.0),
            child: Row(
              children: [
                const Icon(Icons.attach_file, size: 16, color: Colors.grey),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    file.path.split('/').last,
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close, size: 16, color: Colors.grey),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  onPressed: () {
                    setState(() {
                      _invoiceDocument = null;
                    });
                  },
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildSuccessScreen() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.blue[50],
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.check_circle,
                color: Colors.blue[700],
                size: 80,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Document téléchargé avec succès!',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.blue[700],
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Text(
              'Votre ${widget.invoiceType.toLowerCase()} a été enregistrée.',
              style: const TextStyle(fontSize: 16, color: Colors.black87),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                _resetForm();
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const DocumentTypeSelectionScreen(),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2196F3),
                minimumSize: const Size(200, 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text(
                'Télécharger un autre document',
                style: TextStyle(fontSize: 16, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Widget pour la barre de navigation du bas (partagé entre tous les écrans)
Widget _buildBottomNavigationBar(BuildContext context, int currentIndex) {
  return Container(
    decoration: BoxDecoration(
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.05),
          blurRadius: 10,
          offset: const Offset(0, -5),
        ),
      ],
    ),
    child: ClipRRect(
      borderRadius: const BorderRadius.only(
        topLeft: Radius.circular(20),
        topRight: Radius.circular(20),
      ),
      child: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFF2196F3),
        unselectedItemColor: Colors.grey,
        currentIndex: 1, // Page actuelle (Documents)
        backgroundColor: Colors.white,
        elevation: 10,
        selectedLabelStyle: const TextStyle(
          fontWeight: FontWeight.w500,
          fontSize: 12,
        ),
        unselectedLabelStyle: const TextStyle(fontSize: 12),
        onTap: (index) {
          if (index == 0) {
            Navigator.pushReplacementNamed(context, '/home');
          } else if (index == 1) {
            Navigator.pushReplacementNamed(context, '/upload');
          } else if (index == 2) {
            Navigator.pushReplacementNamed(context, '/documents');
          } else if (index == 3) {
            Navigator.pushReplacementNamed(context, '/profile');
          }
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_rounded),
            activeIcon: Icon(Icons.home_rounded, size: 28),
            label: 'Accueil',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.upload_file_outlined),
            activeIcon: Icon(Icons.upload_file_rounded, size: 28),
            label: 'Télécharger',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.folder_outlined),
            activeIcon: Icon(Icons.folder_rounded, size: 28),
            label: 'Documents',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline_rounded),
            activeIcon: Icon(Icons.person_rounded, size: 28),
            label: 'Profil',
          ),
        ],
      ),
    ),
  );
}
