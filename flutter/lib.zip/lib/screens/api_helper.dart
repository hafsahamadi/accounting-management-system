import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Configuration class for API endpoints
class ApiConfig {
  // Base URL of the API - change according to environment
  static const String baseUrl = "http://192.168.1.78:8000/api";

  // For easy environment switching
  static String getBaseUrl() {
    return baseUrl;
  }

  // URL builders for different routes
  static Uri getLoginUrl() {
    return Uri.parse('${getBaseUrl()}/entreprise/login');
  }
  
  static Uri getValidateTokenUrl() {
    return Uri.parse('${getBaseUrl()}/validate-token');
  }
  
  static Uri getLogoutUrl() {
    return Uri.parse('${getBaseUrl()}/logout');
  }
}

/// Authentication service for managing user sessions
class AuthService {
  // Using secure storage for sensitive data
  static final storage = FlutterSecureStorage();

  /// Login method for enterprise users
  /// Returns true if login was successful
  static Future<bool> loginEntreprise(String nomUtilisateur, String motDePasse) async {
    try {
      final url = ApiConfig.getLoginUrl();
      print('🔵 Sending login request to $url');

      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'nom_utilisateur': nomUtilisateur,
          'mot_de_passe': motDePasse,
        }),
      );

      print('🟡 Status Code: ${response.statusCode}');
      print('🟡 Response: ${response.body}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data.containsKey('token')) {
          final token = data['token'];
          // Store token in secure storage
          await storage.write(key: 'token', value: token);
          
          // Also mark as logged in via SharedPreferences for quicker checks
          final prefs = await SharedPreferences.getInstance();
          await prefs.setBool('isLoggedIn', true);
          await prefs.setString('username', nomUtilisateur);
          
          print('🟢 Login successful — token stored.');
          return true;
        } else {
          print('🔴 Token missing in response: $data');
          return false;
        }
      } else {
        print('🔴 HTTP Error: ${response.statusCode} => ${response.body}');
        return false;
      }
    } catch (e) {
      print('🔴 Exception during login: $e');
      return false;
    }
  }

  /// Check if user is currently logged in
  static Future<bool> isLoggedIn() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final isLoggedIn = prefs.getBool('isLoggedIn') ?? false;
      
      // For stronger verification, check if token exists
      final token = await storage.read(key: 'token');
      
      if (!isLoggedIn || token == null || token.isEmpty) {
        return false;
      }
      
      // Optional: Validate token with server
      try {
        final response = await http.get(
          ApiConfig.getValidateTokenUrl(),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer $token',
          },
        );
        
        // If token is no longer valid, clear stored data
        if (response.statusCode != 200) {
          await logout();
          return false;
        }
      } catch (e) {
        // On connection error, consider user still logged in
        // to avoid disconnecting due to temporary network issues
        print('🟠 Error validating token: $e');
      }
      
      return true;
    } catch (e) {
      print('🔴 Error checking login status: $e');
      return false;
    }
  }

  /// Get the authentication token
  static Future<String?> getToken() async {
    return await storage.read(key: 'token');
  }

  /// Logout user and clear stored credentials
  static Future<bool> logout() async {
    try {
      final token = await getToken();
      
      if (token != null && token.isNotEmpty) {
        // Optional: Inform server about logout
        try {
          await http.post(
            ApiConfig.getLogoutUrl(),
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer $token',
            },
          );
        } catch (e) {
          print('🟠 Error during server-side logout: $e');
          // Continue despite error
        }
      }
      
      // Clear stored data
      await storage.delete(key: 'token');
      
      // Also clear SharedPreferences data
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('isLoggedIn', false);
      await prefs.remove('username');
      
      print('🟢 Logout successful');
      return true;
    } catch (e) {
      print('🔴 Error during logout: $e');
      return false;
    }
  }
  
  /// Get the current username
  static Future<String?> getUsername() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString('username');
    } catch (e) {
      return null;
    }
  }
}