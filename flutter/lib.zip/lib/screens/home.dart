import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart'; // Ajout de cette dépendance
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'auth_service.dart';

// --- Fonction pour récupérer le token (globale ou importée) ---
Future<String?> getAuthToken() async {
  const storage = FlutterSecureStorage();
  String? token = await storage.read(key: 'token');
  if (token != null && token.isNotEmpty) {
    print(
      "[getAuthToken] Token lu: ${token.length > 10 ? token.substring(0, 10) + '...' : token}",
    );
  } else {
    print("[getAuthToken] Token lu: ${token == null ? 'NULL' : 'VIDE'}");
  }
  return token;
}

// --- Constantes API (globales ou importées) ---
const String API_BASE_URL = "http://192.168.1.78:8000/api";
const String BASE_STORAGE_URL = "http://192.168.1.78:8000/storage/";

// --- Classe Modèle DocumentItem ---
class DocumentItem {
  final int id;
  final String? filePath;
  final String title;
  final String time;
  final String fileType;
  final Color typeColor;

  DocumentItem({
    required this.id,
    this.filePath,
    required this.title,
    required this.time,
    required this.fileType,
    required this.typeColor,
  });

  String? get documentUrl {
    if (filePath != null && filePath!.isNotEmpty) {
      String path = filePath!;
      if (path.startsWith('/')) path = path.substring(1);
      return BASE_STORAGE_URL + path;
    }
    return null;
  }
}

// --- Clé pour les préférences partagées ---
const String WELCOME_NOTIFICATION_KEY = 'last_welcome_notification_time';

// --- Classe Principale ---
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with SingleTickerProviderStateMixin {
  Map<String, int> documentStatuses = {};
  List<DocumentItem> recentDocuments = [];

  late AnimationController _animationController;
  late Animation<double> _animation;
  late Dio _dio;
  bool _isLoadingRecent = true;
  bool _isLoadingStatus = true;
  bool _showNotification = false;
  String? _errorMessageRecent;
  String? _errorMessageStatus;
  String userName = "";
  final String _currentIp =
      "192.168.1.78"; // Mettez à jour si votre IP serveur change

  @override
  void initState() {
    super.initState();
     
    _dio = Dio(); // initialisation
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );
    _animation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOutQuart,
    );

    _loadData();
    _loadUserInfo();
    _checkWelcomeNotification();

    Future.delayed(const Duration(milliseconds: 800), () {
      if (mounted) _animationController.forward();
    });
  }

  // Nouvelle méthode pour gérer la notification de bienvenue
  Future<void> _checkWelcomeNotification() async {
    // Récupération des SharedPreferences
    final prefs = await SharedPreferences.getInstance();

    // Vérifier s'il faut afficher la notification de bienvenue
    final lastNotificationTime = prefs.getInt(WELCOME_NOTIFICATION_KEY) ?? 0;
    final currentTime = DateTime.now().millisecondsSinceEpoch;

    // On n'affiche la notification que si:
    // 1. C'est la première fois (lastNotificationTime = 0)
    // 2. Ou si la dernière notification était il y a plus de 24 heures
    final shouldShowNotification =
        lastNotificationTime == 0 ||
        currentTime - lastNotificationTime > 24 * 60 * 60 * 1000;

    if (shouldShowNotification && mounted) {
      // Sauvegarder le timestamp actuel
      await prefs.setInt(WELCOME_NOTIFICATION_KEY, currentTime);

      // Afficher la notification avec un délai
      Future.delayed(const Duration(milliseconds: 300), () {
        if (mounted) {
          setState(() {
            _showNotification = true;
          });
          Future.delayed(const Duration(seconds: 5), () {
            if (mounted) {
              setState(() {
                _showNotification = false;
              });
            }
          });
        }
      });
    } else {
      // Ne pas afficher la notification
      _showNotification = false;
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadUserInfo() async {
    final String? token = await getAuthToken();
    if (token == null || token.isEmpty) {
      if (mounted) {
        setState(() {
          userName = "Invité";
        });
      }
      return;
    }

    final dio = Dio();
    // création de l'instance ici
    // Assurez-vous que cette URL correspond à votre route backend
    final url = 'http://$_currentIp:8000/api/profile';
    print('➡️ Appel API (Dio) User Info: GET $url');

    try {
      final response = await dio.get(
        url,
        options: Options(
          headers: {
            'Authorization': 'Bearer $token',
            'Accept': 'application/json',
          },
          receiveTimeout: const Duration(seconds: 10),
          sendTimeout: const Duration(seconds: 10),
        ),
      );

      print('⬅️ [loadUserInfo] Réponse Status: ${response.statusCode}');
      print('⬅️ [loadUserInfo] Réponse Body: ${response.data}');

      if (response.statusCode == 200 && response.data != null) {
        final userData = response.data;
        if (mounted) {
          setState(() {
            // Extraction du prénom avec une gestion robuste des valeurs nulles
            String extractedName = '';

            // Vérifier explicitement si le champ 'prenom' existe et n'est pas vide
            if (userData['prenom'] != null &&
                userData['prenom'].toString().isNotEmpty) {
              extractedName = userData['prenom'].toString();
              print('✅ Prénom trouvé directement: $extractedName');
            }
            // Fallback au nom de l'entreprise pour les comptes entreprise
            else if (userData['nom_entreprise'] != null &&
                userData['nom_entreprise'].toString().isNotEmpty) {
              extractedName = userData['nom_entreprise'].toString();
              print('✅ Nom entreprise utilisé: $extractedName');
            }
            // Fallback au nom complet pour les utilisateurs standards
            else if (userData['name'] != null &&
                userData['name'].toString().isNotEmpty) {
              final fullName = userData['name'].toString();
              final parts = fullName.split(' ');
              extractedName = parts.isNotEmpty ? parts[0] : 'Utilisateur';
              print('✅ Prénom extrait du nom complet: $extractedName');
            }
            // Valeur par défaut si rien n'est disponible
            else {
              extractedName = 'Utilisateur';
              print('⚠️ Aucun nom trouvé, utilisation valeur par défaut');
            }

            userName = extractedName;
            print('✅ Nom utilisateur final: $userName');
          });
        }
      } else {
        print('❌ Erreur API: ${response.statusCode}');
        if (mounted) {
          setState(() {
            userName = "Utilisateur";
          });
        }
      }
    } catch (e) {
      print('❌ Exception [loadUserInfo]: $e');
      if (mounted) {
        setState(() {
          userName = "Utilisateur";
        });
      }
    }
  }

  Future<void> _loadData() async {
    final token = await getAuthToken();
    final response = await _dio.get('http://...');
    if (mounted) {
      setState(() {
        _isLoadingRecent = true;
        _isLoadingStatus = true;
        _errorMessageRecent = null;
        _errorMessageStatus = null;
      });
    }
    await Future.wait([fetchStatusCounts(), fetchRecentDocuments()]);
  }

  Future<void> fetchStatusCounts() async {
    final String? token = await getAuthToken();
    if (token == null || token.isEmpty) {
      if (mounted)
        setState(() {
          _isLoadingStatus = false;
          _errorMessageStatus = "Authentification requise.";
        });
      return;
    }
    final dio = Dio();
    final url = 'http://$_currentIp:8000/api/documents/status-counts';
    print('➡️ Appel API (Dio) Status Counts: GET $url');
    try {
      final response = await dio.get(
        url,
        options: Options(
          headers: {
            'Authorization': 'Bearer $token',
            'Accept': 'application/json',
          },
          receiveTimeout: const Duration(seconds: 20),
          sendTimeout: const Duration(seconds: 20),
        ),
      );
      print('⬅️ [fetchStatusCounts] Réponse Status: ${response.statusCode}');
      if (response.statusCode == 200 &&
          response.data != null &&
          response.data is Map<String, dynamic>) {
        final data = response.data as Map<String, dynamic>;
        if (mounted) {
          setState(() {
            documentStatuses = {
              'En cours': (data['En cours'] ?? data['en_cours'] ?? 0) as int,
              'Validé': (data['Validé'] ?? data['valide'] ?? 0) as int,
              'À revoir': (data['À revoir'] ?? data['a_revoir'] ?? 0) as int,
            };
            _isLoadingStatus = false;
          });
        }
      } else {
        if (mounted)
          setState(() {
            _isLoadingStatus = false;
            _errorMessageStatus = "Erreur serveur (${response.statusCode}).";
          });
      }
    } catch (e) {
      print('❌ Exception [fetchStatusCounts]: $e');
      if (mounted) {
        setState(() {
          documentStatuses = {'En cours': 3, 'Validé': 8, 'À revoir': 1};
          _isLoadingStatus = false;
          _errorMessageStatus = "Erreur connexion (données simulées)";
        });
      }
    }
  }

  Future<void> fetchRecentDocuments() async {
    final String? token = await getAuthToken();
    if (token == null || token.isEmpty) {
      if (mounted)
        setState(() {
          _isLoadingRecent = false;
          recentDocuments = [];
          _errorMessageRecent = "Authentification requise.";
        });
      return;
    }
    final dio = Dio();
    final url = 'http://$_currentIp:8000/api/documents/recent-documents';
    print('➡️ Appel API (Dio) Recent Docs: GET $url');
    try {
      final response = await dio.get(
        url,
        options: Options(
          headers: {
            'Authorization': 'Bearer $token',
            'Accept': 'application/json',
          },
          receiveTimeout: const Duration(seconds: 20),
          sendTimeout: const Duration(seconds: 20),
        ),
      );
      print('⬅️ [fetchRecentDocuments] Réponse Status: ${response.statusCode}');
      if (response.statusCode == 200 &&
          response.data != null &&
          response.data is List) {
        final List<dynamic> data = response.data;
        if (mounted) {
          setState(() {
            recentDocuments =
                data.map((doc) {
                  final id =
                      doc['id'] as int? ??
                      DateTime.now().millisecondsSinceEpoch;
                  final filePath = doc['chemin_fichier'] as String?;
                  final title = doc['nom_fichier'] ?? 'Document Inconnu';
                  final time =
                      doc['created_at']?.toString() ??
                      DateTime.now().toIso8601String();
                  final fileTypeApi = doc['type'] ?? 'inconnu';

                  Color typeColor = Colors.grey;
                  String displayFileType = "DOC";
                  if (fileTypeApi.contains('facture_achat')) {
                    typeColor = Color(0xFF3B82F6);
                    displayFileType = 'F.ACHAT';
                  } else if (fileTypeApi.contains('facture_vente')) {
                    typeColor = Color(0xFF10B981);
                    displayFileType = 'F.VENTE';
                  } else if (fileTypeApi.contains('bon_livraison')) {
                    typeColor = Color(0xFFF59E0B);
                    displayFileType = 'B.L.';
                  } else if (fileTypeApi == 'pdf') {
                    typeColor = Color(0xFFEF4444);
                    displayFileType = 'PDF';
                  } else if (['jpg', 'jpeg', 'png'].contains(fileTypeApi)) {
                    typeColor = Color(0xFFA855F7);
                    displayFileType = 'IMG';
                  }

                  return DocumentItem(
                    id: id,
                    filePath: filePath,
                    title: title,
                    time: time,
                    fileType: displayFileType,
                    typeColor: typeColor,
                  );
                }).toList();
            _isLoadingRecent = false;
          });
        }
      } else {
        if (mounted)
          setState(() {
            _isLoadingRecent = false;
            recentDocuments = [];
            _errorMessageRecent =
                "Erreur serveur (${response.statusCode}) (docs).";
          });
      }
    } catch (e) {
      print('❌ Exception [fetchRecentDocuments]: $e');
      if (mounted) {
        setState(() {
          recentDocuments = [
            DocumentItem(
              id: 1,
              title: 'Facture F001 Alpha.pdf',
              time:
                  DateTime.now().subtract(Duration(hours: 2)).toIso8601String(),
              fileType: 'PDF',
              typeColor: Color(0xFFEF4444),
              filePath: 'dummy/path.pdf',
            ),
            DocumentItem(
              id: 2,
              title: 'Bon Livraison #BL034',
              time:
                  DateTime.now().subtract(Duration(days: 1)).toIso8601String(),
              fileType: 'B.L.',
              typeColor: Color(0xFFF59E0B),
              filePath: 'dummy/path.pdf',
            ),
            DocumentItem(
              id: 3,
              title: 'Achat Fourniture Bureau',
              time:
                  DateTime.now()
                      .subtract(Duration(days: 2, hours: 5))
                      .toIso8601String(),
              fileType: 'F.ACHAT',
              typeColor: Color(0xFF3B82F6),
              filePath: 'dummy/path.pdf',
            ),
          ];
          _isLoadingRecent = false;
          _errorMessageRecent = "Erreur connexion (données simulées)";
        });
      }
    }
  }

  bool _showDialog = false;

  void _toggleDialog() {
    setState(() {
      _showDialog = !_showDialog;
    });
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final bool isSmallScreen = screenSize.width < 600;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          Container(decoration: BoxDecoration(color: Colors.white)),
          Container(
            height: 200,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  const Color(0xFF2563EB),
                  const Color(0xFF3B82F6).withOpacity(0.9),
                ],
              ),
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(35),
                bottomRight: Radius.circular(35),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.08),
                  blurRadius: 15,
                  offset: Offset(0, 5),
                ),
              ],
            ),
          ),
          SafeArea(
            child: RefreshIndicator(
              onRefresh: _loadData,
              color: const Color(0xFF2563EB),
              child: CustomScrollView(
                slivers: [
                  SliverAppBar(
                    backgroundColor: Colors.transparent,
                    elevation: 0,
                    pinned: true,
                    floating: false,
                    automaticallyImplyLeading: false,
                    toolbarHeight: 70,
                    flexibleSpace: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 10,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Image.asset(
                                'assets/logo.png',
                                height: 56,
                                width: 56,
                              ),
                              const SizedBox(width: 10),
                            ],
                          ),
                          Row(
                            children: [
                              GestureDetector(
                                onTap: _toggleDialog,
                                child: CircleAvatar(
                                  radius: 18,
                                  backgroundColor: Colors.white.withOpacity(
                                    0.9,
                                  ),
                                  child: Text(
                                    userName.isNotEmpty
                                        ? userName[0].toUpperCase()
                                        : "U",
                                    style: const TextStyle(
                                      color: Color(0xFF2563EB),
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Bienvenue, ${userName.split(' ').first} !',
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            'Votre espace de gestion documentaire.',
                            style: TextStyle(
                              fontSize: 15,
                              color: Colors.white.withOpacity(0.85),
                            ),
                          ),
                          const SizedBox(height: 25),
                        ],
                      ),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: const EdgeInsets.only(bottom: 25, top: 0),
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            height: 52,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.05),
                                  blurRadius: 10,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Row(
                              children: [
                                const Padding(
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 8.0,
                                  ),
                                  child: Icon(
                                    Icons.search,
                                    color: Color(0xFF64748B),
                                    size: 22,
                                  ),
                                ),
                                Expanded(
                                  child: TextField(
                                    decoration: InputDecoration(
                                      hintText: 'Rechercher un document...',
                                      border: InputBorder.none,
                                      hintStyle: TextStyle(
                                        color: const Color(0xFF94A3B8),
                                        fontSize: 15,
                                      ),
                                    ),
                                    style: const TextStyle(fontSize: 15),
                                  ),
                                ),
                                IconButton(
                                  icon: Icon(
                                    Icons.filter_list_rounded,
                                    color: Color(0xFF64748B),
                                    size: 22,
                                  ),
                                  onPressed: () {},
                                ),
                              ],
                            ),
                          ),
                          const Text(
                            'Vue d\'ensemble',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF1E293B),
                            ),
                          ),
                          const SizedBox(height: 16),
                          if (_errorMessageStatus != null && !_isLoadingStatus)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 16.0),
                              child: Center(
                                child: Text(
                                  '$_errorMessageStatus',
                                  style: const TextStyle(
                                    color: Colors.red,
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                            ),
                          _isLoadingStatus
                              ? const Center(
                                child: Padding(
                                  padding: EdgeInsets.symmetric(vertical: 30),
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      Color(0xFF2563EB),
                                    ),
                                  ),
                                ),
                              )
                              : AnimatedBuilder(
                                animation: _animation,
                                builder: (context, child) {
                                  return Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      _buildAnimatedStatusCard(
                                        context,
                                        'En cours',
                                        documentStatuses['En cours']
                                                ?.toString() ??
                                            '0',
                                        const Color(0xFF3B82F6),
                                        Icons.hourglass_empty_rounded,
                                        0,
                                        isSelected: true,
                                      ),
                                      _buildAnimatedStatusCard(
                                        context,
                                        'Validé',
                                        documentStatuses['Validé']
                                                ?.toString() ??
                                            '0',
                                        const Color(0xFF10B981),
                                        Icons.check_circle_outline_rounded,
                                        1,
                                      ),
                                      _buildAnimatedStatusCard(
                                        context,
                                        'À revoir',
                                        documentStatuses['À revoir']
                                                ?.toString() ??
                                            '0',
                                        const Color(0xFFF43F5E),
                                        Icons.error_outline_rounded,
                                        2,
                                      ),
                                    ],
                                  );
                                },
                              ),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'Documents Récents',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                  color: Color(0xFF1E293B),
                                ),
                              ),
                              TextButton.icon(
                                onPressed:
                                    () => Navigator.pushReplacementNamed(
                                      context,
                                      '/documents',
                                    ),
                                icon: const Icon(
                                  Icons.arrow_forward_ios_rounded,
                                  size: 16,
                                  color: Color(0xFF3B82F6),
                                ),
                                label: const Text(
                                  'Voir tout',
                                  style: TextStyle(
                                    color: Color(0xFF3B82F6),
                                    fontWeight: FontWeight.w500,
                                    fontSize: 14,
                                  ),
                                ),
                                style: TextButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 0,
                                    vertical: 6,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          if (_errorMessageRecent != null && !_isLoadingRecent)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 16.0),
                              child: Center(
                                child: Text(
                                  '$_errorMessageRecent',
                                  style: const TextStyle(
                                    color: Colors.red,
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                            ),
                          _isLoadingRecent
                              ? const Center(
                                child: Padding(
                                  padding: EdgeInsets.symmetric(vertical: 40.0),
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      Color(0xFF2563EB),
                                    ),
                                  ),
                                ),
                              )
                              : recentDocuments.isEmpty
                              ? Center(
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 40.0,
                                  ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.inbox_outlined,
                                        size: 48,
                                        color: Colors.grey[350],
                                      ),
                                      const SizedBox(height: 12),
                                      Text(
                                        _errorMessageRecent == null
                                            ? 'Aucun document récent.'
                                            : '',
                                        style: TextStyle(
                                          fontSize: 15,
                                          color: Colors.grey.shade600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              )
                              : ListView.builder(
                                physics: const NeverScrollableScrollPhysics(),
                                shrinkWrap: true,
                                itemCount: math.min(recentDocuments.length, 4),
                                itemBuilder: (context, index) {
                                  final delay = index * 0.1;
                                  final animValue =
                                      _animation.value > delay
                                          ? (_animation.value - delay) /
                                              (1 - delay)
                                          : 0.0;
                                  return Transform.translate(
                                    offset: Offset(0, 20 * (1 - animValue)),
                                    child: Opacity(
                                      opacity: animValue.clamp(0.0, 1.0),
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                          bottom: 10.0,
                                        ),
                                        child: _buildDocumentItem(
                                          context,
                                          recentDocuments[index],
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                          Container(
                            width: double.infinity,
                            margin: const EdgeInsets.symmetric(vertical: 30),
                            height: 52,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(14),
                              gradient: const LinearGradient(
                                colors: [Color(0xFF3B82F6), Color(0xFF2563EB)],
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(
                                    0xFF2563EB,
                                  ).withOpacity(0.3),
                                  blurRadius: 10,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: ElevatedButton.icon(
                              onPressed:
                                  () => Navigator.pushReplacementNamed(
                                    context,
                                    '/upload',
                                  ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.transparent,
                                shadowColor: Colors.transparent,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                              icon: const Icon(
                                Icons.add_circle_outline_rounded,
                                color: Colors.white,
                                size: 22,
                              ),
                              label: const Text(
                                'Ajouter un document',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (_showNotification) /* ... Notification de bienvenue ... */
            Positioned(
              top: MediaQuery.of(context).padding.top + 80,
              left: 16,
              right: 16,
              child: SlideTransition(
                position: Tween<Offset>(
                  begin: const Offset(0, -1.5),
                  end: Offset.zero,
                ).animate(
                  CurvedAnimation(
                    parent: _animationController,
                    curve: Interval(0.4, 0.7, curve: Curves.elasticOut),
                  ),
                ),
                child: FadeTransition(
                  opacity: Tween<double>(begin: 0.0, end: 1.0).animate(
                    CurvedAnimation(
                      parent: _animationController,
                      curve: Interval(0.4, 0.6, curve: Curves.easeOut),
                    ),
                  ),
                  child: Material(
                    elevation: 6,
                    borderRadius: BorderRadius.circular(12),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      decoration: BoxDecoration(
                        color: Color(0xFFE0F2FE),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: Color(0xFF7DD3FC).withOpacity(0.5),
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.campaign_outlined,
                            color: Color(0xFF0EA5E9),
                            size: 22,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Bienvenue, ${userName.split(' ').first}!',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF0C4A6E),
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  'Ravi de vous revoir sur ComptaLink.',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Color(0xFF0C4A6E).withOpacity(0.9),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            icon: Icon(
                              Icons.close_rounded,
                              size: 18,
                              color: Color(0xFF38BDF8),
                            ),
                            onPressed: () {
                              if (mounted)
                                setState(() {
                                  _showNotification = false;
                                });
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),

          // Ajouter cette partie pour le menu
          if (_showDialog)
            Positioned(
              top: 80,
              right: 20,
              child: Material(
                elevation: 4.0,
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  width: 200,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Bonjour $userName!',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text('Voici votre profil:'),
                      const SizedBox(height: 10),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.person),
                        title: const Text('Mon profil'),
                        dense: true,
                        onTap: () {
                          // Action pour voir le profil
                          _toggleDialog();
                        },
                      ),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.settings),
                        title: const Text('Paramètres'),
                        dense: true,
                        onTap: () {
                          // Action pour les paramètres
                          _toggleDialog();
                        },
                      ),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.logout),
                        title: const Text('Déconnexion'),
                        dense: true,
                        onTap: () async {
                          _toggleDialog();
                          await AuthService.logout(context, _dio);
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
      // --- INTÉGRATION DE LA BOTTOMNAVIGATIONBAR ---
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
          child: BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            selectedItemColor: const Color(0xFF2196F3),
            unselectedItemColor: Colors.grey,
            currentIndex: 0,
            backgroundColor: Colors.white,
            elevation: 10,
            selectedLabelStyle: const TextStyle(
              fontWeight: FontWeight.w500,
              fontSize: 12,
            ),
            unselectedLabelStyle: const TextStyle(fontSize: 12),
            onTap: (index) {
              if (index == 0) return; // Déjà sur l'accueil
              String routeName;
              switch (index) {
                case 1:
                  routeName = '/upload';
                  break;
                case 2:
                  routeName = '/documents';
                  break;
                case 3:
                  routeName = '/profile';
                  break;
                default:
                  return;
              }
              Navigator.pushReplacementNamed(context, routeName);
            },
            items: const [
              BottomNavigationBarItem(
                icon: Icon(Icons.home_outlined, size: 24),
                activeIcon: Icon(Icons.home_rounded, size: 26),
                label: 'Accueil',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.cloud_upload_outlined, size: 24),
                activeIcon: Icon(Icons.add_circle_rounded, size: 26),
                label: 'Déposer',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.folder_copy_outlined, size: 24),
                activeIcon: Icon(Icons.folder_copy_rounded, size: 26),
                label: 'Documents',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.person_outline_rounded, size: 24),
                activeIcon: Icon(Icons.person_rounded, size: 26),
                label: 'Profil',
              ),
            ],
          ),
        ),
      ),
    );
  }

  // --- Widgets de construction internes ---
  Widget _buildDocumentItem(BuildContext context, DocumentItem docItem) {
    String formattedTime = 'Date inconnue';
    try {
      DateTime? parsedDate = DateTime.tryParse(docItem.time);
      if (parsedDate != null) {
        try {
          formattedTime = DateFormat(
            'dd MMM yy, HH:mm',
            'fr_FR',
          ).format(parsedDate.toLocal());
        } catch (_) {
          final ld = parsedDate.toLocal();
          formattedTime = "${ld.day}/${ld.month} ${ld.hour}:${ld.minute}";
        }
      }
    } catch (e) {
      formattedTime = docItem.time;
    }

    return Card(
      elevation: 1.0,
      margin: const EdgeInsets.only(bottom: 10.0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      color: Colors.white,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {
          print(
            "Voir doc: ${docItem.title}",
          ); /* TODO: _viewDocument(docItem) */
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 12.0),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: docItem.typeColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text(
                    docItem.fileType,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: docItem.typeColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 9,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      docItem.title,
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                        color: Color(0xFF374151),
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      formattedTime,
                      style: TextStyle(
                        color: Colors.grey.shade500,
                        fontSize: 11.5,
                      ),
                    ),
                  ],
                ),
              ),
              PopupMenuButton<String>(
                icon: Icon(
                  Icons.more_vert_rounded,
                  color: Colors.grey.shade400,
                  size: 20,
                ),
                tooltip: "Options",
                offset: Offset(0, 35),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                itemBuilder:
                    (context) => [
                      _buildPopupMenuItem(
                        context,
                        Icons.visibility_outlined,
                        'Aperçu',
                        'view',
                      ),
                      _buildPopupMenuItem(
                        context,
                        Icons.edit_outlined,
                        'Renommer',
                        'rename',
                      ),
                      _buildPopupMenuItem(
                        context,
                        Icons.file_download_outlined,
                        'Ouvrir',
                        'download',
                      ),
                      _buildPopupMenuItem(
                        context,
                        Icons.share_outlined,
                        'Partager',
                        'share',
                      ),
                      const PopupMenuDivider(height: 1),
                      _buildPopupMenuItem(
                        context,
                        Icons.delete_outline_rounded,
                        'Supprimer',
                        'delete',
                        isDestructive: true,
                      ),
                    ],
                onSelected: (value) {
                  // --- IMPORTANT: Appeler les fonctions d'action de _DashboardScreenState ---
                  // Vous devrez passer l'objet docItem ou ses propriétés nécessaires
                  print(
                    "Action '$value' pour '${docItem.title}' avec ID ${docItem.id}",
                  );
                  // if (value == 'view') _viewDocument(docItem); // Décommentez et implémentez
                  // if (value == 'rename') _showRenameDialog(docItem); // Décommentez et implémentez
                  // if (value == 'download') _launchDocumentUrl(docItem, "téléchargement"); // Décommentez et implémentez
                  // if (value == 'share') _shareDocument(docItem); // Décommentez et implémentez
                  // if (value == 'delete') _deleteDocument(docItem); // Décommentez et implémentez
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  PopupMenuItem<String> _buildPopupMenuItem(
    BuildContext context,
    IconData icon,
    String text,
    String value, {
    bool isDestructive = false,
  }) {
    Color itemColor =
        isDestructive
            ? Colors.red.shade600
            : Theme.of(context).textTheme.bodyLarge?.color?.withOpacity(0.8) ??
                Colors.black87;
    return PopupMenuItem<String>(
      value: value,
      height: 42,
      child: Row(
        children: [
          Icon(icon, size: 18, color: itemColor),
          SizedBox(width: 10),
          Text(text, style: TextStyle(color: itemColor, fontSize: 13.5)),
        ],
      ),
    );
  }

  Widget _buildAnimatedStatusCard(
    BuildContext context,
    String title,
    String value,
    Color color,
    IconData icon,
    int index, {
    bool isSelected = false,
  }) {
    final delay = index * 0.1;
    final animValue =
        _animation.value > delay
            ? (_animation.value - delay).clamp(0.0, 1.0) / (1 - delay)
            : 0.0;
    return Expanded(
      child: Padding(
        padding: EdgeInsets.only(
          left: index == 0 ? 0 : 6,
          right: index == 2 ? 0 : 6,
        ),
        child: Transform.scale(
          scale: 0.9 + (0.1 * animValue),
          child: Opacity(
            opacity: animValue,
            child: Card(
              elevation:
                  isSelected ? 3.5 : 1.5, // Ombre plus prononcée si sélectionné
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
                side: BorderSide(
                  color:
                      isSelected ? color.withOpacity(0.7) : Colors.transparent,
                  width: 1.5,
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 14,
                ), // Padding ajusté
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(7),
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(icon, color: color, size: 18),
                        ),
                        Text(
                          value,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: color,
                          ),
                        ), // Taille de police réduite
                      ],
                    ),
                    const SizedBox(height: 8), // Espace réduit
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey.shade600,
                        fontWeight: FontWeight.w500,
                      ),
                    ), // Taille de police réduite
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
