import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Environment {
  final String name;
  final String baseUrl;

  Environment({required this.name, required this.baseUrl});
}

class EnvironmentManager {
  static const String _prefKey = 'selected_environment';
  static Environment? _currentEnvironment;

  static final List<Environment> environments = [
    Environment(name: 'Local', baseUrl: 'http://192.168.1.78:8000/api'),
    Environment(name: 'ngrok', baseUrl: 'https://votre-url-ngrok.ngrok.io/api'),
    Environment(name: 'Production', baseUrl: 'https://votre-serveur-de-production.com/api'),
    // Ajoutez d'autres environnements selon vos besoins
  ];

  static Future<Environment> getCurrentEnvironment() async {
    if (_currentEnvironment != null) {
      return _currentEnvironment!;
    }

    final prefs = await SharedPreferences.getInstance();
    final savedEnvName = prefs.getString(_prefKey);
    
    if (savedEnvName != null) {
      final env = environments.firstWhere(
        (env) => env.name == savedEnvName,
        orElse: () => environments.first,
      );
      _currentEnvironment = env;
      return env;
    }
    
    // Par défaut, utilisez le premier environnement
    _currentEnvironment = environments.first;
    return environments.first;
  }

  static Future<void> setCurrentEnvironment(Environment environment) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefKey, environment.name);
    _currentEnvironment = environment;
  }
}

class EnvironmentSelectorScreen extends StatefulWidget {
  @override
  _EnvironmentSelectorScreenState createState() => _EnvironmentSelectorScreenState();
}

class _EnvironmentSelectorScreenState extends State<EnvironmentSelectorScreen> {
  Environment? _selectedEnvironment;
  final TextEditingController _customUrlController = TextEditingController();
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadCurrentEnvironment();
  }

  Future<void> _loadCurrentEnvironment() async {
    final env = await EnvironmentManager.getCurrentEnvironment();
    setState(() {
      _selectedEnvironment = env;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sélection de l\'environnement'),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Sélectionnez l\'environnement de l\'API',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 16),
                  for (var env in EnvironmentManager.environments)
                    RadioListTile<Environment>(
                      title: Text(env.name),
                      subtitle: Text(env.baseUrl),
                      value: env,
                      groupValue: _selectedEnvironment,
                      onChanged: (Environment? value) {
                        setState(() {
                          _selectedEnvironment = value;
                        });
                      },
                    ),
                  SizedBox(height: 16),
                  Text(
                    'URL personnalisée',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  TextField(
                    controller: _customUrlController,
                    decoration: InputDecoration(
                      hintText: 'https://votre-api-personnalisee.com/api',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () async {
                        if (_customUrlController.text.isNotEmpty) {
                          final customEnv = Environment(
                            name: 'Personnalisé',
                            baseUrl: _customUrlController.text,
                          );
                          await EnvironmentManager.setCurrentEnvironment(customEnv);
                        } else if (_selectedEnvironment != null) {
                          await EnvironmentManager.setCurrentEnvironment(_selectedEnvironment!);
                        }
                        Navigator.pop(context);
                      },
                      child: Text('Valider'),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}