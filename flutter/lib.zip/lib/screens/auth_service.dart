import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  static const String _baseUrl = "http://192.168.1.78:8000/api";
  static const String WELCOME_NOTIFICATION_KEY = 'welcome_notification';

  static Future<String?> getAuthToken() async {
    const storage = FlutterSecureStorage();
    return await storage.read(key: 'token');
  }

  static Future<void> logout(BuildContext context, Dio dio) async {
    final token = await getAuthToken();

    if (token == null) {
      _navigateToLogin(context);
      return;
    }

    final bool confirmLogout = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Row(
            children: [
              Icon(Icons.logout, color: Colors.orange.shade700),
              SizedBox(width: 10),
              const Text('Déconnexion'),
            ],
          ),
          content: const Text('Êtes-vous sûr de vouloir vous déconnecter ?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Annuler'),
            ),
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: Text('Se déconnecter', style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    ) ?? false;

    if (!confirmLogout) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: const [
            CircularProgressIndicator(valueColor: AlwaysStoppedAnimation(Colors.white)),
            SizedBox(width: 15),
            Text("Déconnexion en cours...")
          ],
        ),
        backgroundColor: Theme.of(context).primaryColor,
        duration: Duration(seconds: 5),
      ),
    );

    try {
      await dio.post(
        '$_baseUrl/logout',
        options: Options(headers: {'Authorization': 'Bearer $token'}),
      );
    } catch (_) {}

    const storage = FlutterSecureStorage();
    await storage.delete(key: 'token');
    await storage.delete(key: 'userId');

    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(WELCOME_NOTIFICATION_KEY);

    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    _navigateToLogin(context);
  }

  static void _navigateToLogin(BuildContext context) {
    Navigator.of(context, rootNavigator: true).pushNamedAndRemoveUntil('/', (_) => false);
  }
}
