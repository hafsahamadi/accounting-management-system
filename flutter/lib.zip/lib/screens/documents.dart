// lib/ui/upload_history_page.dart (ou votre chemin)
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:url_launcher/url_launcher.dart'; // Gardez-le pour les URL externes au cas où
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:cross_file/cross_file.dart';
import 'package:open_filex/open_filex.dart';
import 'package:flutter/cupertino.dart';
import 'package:intl/intl.dart';
import 'document_card_widget.dart'; // Importer DocumentCardWidget




// lib/models/document_info.dart

// Vous pouvez garder l'extension ici ou la mettre dans un fichier d'utilitaires séparé si vous en avez d'autres
extension StringExtension on String {
  String capitalize() {
    if (this.isEmpty) return this;
    return "${this[0].toUpperCase()}${this.substring(1)}";
  }
}

class DocumentInfo {
  final int id;
  final String fileName;
  final String type;
  final DateTime uploadedAt;
  final String status;
  final String? filePath;
  final String? entrepriseNom;

  DocumentInfo({
    required this.id,
    required this.fileName,
    required this.type,
    required this.uploadedAt,
    required this.status,
    this.filePath,
    this.entrepriseNom,
  });

  factory DocumentInfo.fromJson(Map<String, dynamic> json) {
    DateTime parsedDate;
    try {
      String? dateStr = json['uploaded_at'] ?? json['created_at'];
      if (dateStr != null) parsedDate = DateTime.parse(dateStr);
      else parsedDate = DateTime.now();
    } catch (e) { parsedDate = DateTime.now(); }
    String statusFromApi = json['statut'] ?? json['status'] ?? 'N/A';
    return DocumentInfo(
      id: json['id'] ?? 0,
      fileName: json['nom_fichier'] ?? 'Nom inconnu',
      type: json['type']?.toLowerCase().trim() ?? 'type_inconnu',
      uploadedAt: parsedDate,
      status: statusFromApi.toLowerCase().trim(),
      filePath: json['chemin_fichier']?.trim(),
      entrepriseNom: json['entreprise'] != null ? json['entreprise']['nom_entreprise'] : null,
    );
  }
  
  String get typeFormatted {
    return type.split('_').map((word) => word.capitalize()).join(' ');
  }
}
// --- FONCTIONS D'API (identiques à avant) ---
const String API_BASE_URL = "http://192.168.1.78:8000/api"; // Votre IP

Future<String?> getAuthToken() async {
  return await const FlutterSecureStorage().read(key: 'token');
}

Future<List<DocumentInfo>> fetchDocuments() async {
  String? token = await getAuthToken();
  if (token == null || token.isEmpty) throw Exception('Token non trouvé.');
  final dio = Dio();
  final url = '$API_BASE_URL/documents';
  try {
    final response = await dio.get(url, 
        options: Options(
            headers: {'Authorization': 'Bearer $token', 'Accept': 'application/json'}, 
            receiveTimeout: const Duration(seconds: 30), 
            sendTimeout: const Duration(seconds: 30),
        ));
    if (response.statusCode == 200 && response.data != null && response.data is List) {
      return (response.data as List).map((json) => DocumentInfo.fromJson(json)).toList();
    } else { 
      throw Exception('Erreur chargement documents: ${response.statusCode}'); 
    }
  } on DioException catch (e) { 
    String errorMessage = 'Erreur réseau.'; 
    if (e.response?.statusCode == 401) errorMessage = 'Session expirée.'; 
    throw Exception(errorMessage); 
  } catch (e) { 
    throw Exception('Erreur inconnue: $e');
  }
}

Future<Map<String, dynamic>?> renameDocument({
  required int documentId,
  required String nouveauNomFichier
}) async {
  String? token = await getAuthToken();
  if (token == null || token.isEmpty) {
    throw Exception("Token d'authentification manquant.");
  }
  final dio = Dio();
  final url = '$API_BASE_URL/documents/$documentId/rename';
  try {
    final response = await dio.patch(
      url,
      data: {'nouveau_nom_fichier': nouveauNomFichier},
      options: Options(
        headers: {'Authorization': 'Bearer $token', 'Accept': 'application/json'},
        receiveTimeout: const Duration(seconds: 30),
        sendTimeout: const Duration(seconds: 30),
      )
    );
    if (response.statusCode == 200 && response.data != null) {
      return response.data as Map<String, dynamic>;
    } else {
      String? apiMessage = response.data?['message'];
      if (apiMessage != null && apiMessage.isNotEmpty) return {'message': apiMessage};
      return {'message': 'Échec du renommage: ${response.statusCode}'};
    }
  } on DioException catch (e) {
    String errorMessage = 'Erreur réseau.';
    if (e.response?.statusCode == 401) errorMessage = 'Session expirée.';
    else if (e.response?.statusCode == 403) errorMessage = 'Non autorisé.';
    else if (e.response?.data != null && e.response!.data['message'] != null) errorMessage = e.response!.data['message'];
    else if (e.response?.statusCode != null) errorMessage = "Erreur serveur (${e.response?.statusCode})";
    return {'message': errorMessage};
  } catch (e) {
    return {'message': 'Erreur inconnue: $e'};
  }
}

Future<bool> deleteDocumentApi(int documentId) async {
 String? token = await getAuthToken();
  if (token == null || token.isEmpty) throw Exception("Token manquant.");
  final dio = Dio();
  final url = '$API_BASE_URL/documents/$documentId';
  try {
    final response = await dio.delete(url, options: Options(headers: {'Authorization': 'Bearer $token', 'Accept': 'application/json'}));
    return response.statusCode == 200 || response.statusCode == 204;
  } catch (e) { throw Exception("Échec suppression: $e"); }
}

// --- PAGE D'HISTORIQUE DES UPLOADS (Mes Documents) ---
class UploadHistoryPage extends StatefulWidget {
  const UploadHistoryPage({Key? key}) : super(key: key);
  @override
  State<UploadHistoryPage> createState() => _UploadHistoryPageState();
}

class _UploadHistoryPageState extends State<UploadHistoryPage> with SingleTickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  List<DocumentInfo> _allDocuments = [];
  List<DocumentInfo> _filteredDocuments = [];
  bool _isLoading = true;
  String? _errorMessage;
  late TabController _tabController;
  
  String _currentStatusFilter = 'tous';
  String _currentTypeFilter = 'tous_types';
  bool _sortAscending = false; // false = plus récent en premier
  bool _isSearchFocused = false;

  // Couleurs du thème (celles que vous avez définies)
  final Color _primaryColor = const Color(0xFF0D47A1); // Bleu marine profond
  final Color _accentColor = const Color(0xFF1976D2); // Bleu plus clair pour accents
  final Color _scaffoldBgColor = const Color(0xFFF4F6F8); // Fond très clair, presque blanc
  final Color _cardColor = Colors.white;
  final Color _successColor = const Color(0xFF388E3C);
  final Color _errorColor = const Color(0xFFD32F2F);
  final Color _warningColor = const Color(0xFFFFA000);
  final Color _neutralColor = const Color(0xFF546E7A); // Gris bleuté
  final Color _textColorPrimary = const Color(0xFF263238); // Gris très foncé pour texte principal
  final Color _textColorSecondary = const Color(0xFF546E7A); // Gris moyen pour texte secondaire

  final ScrollController _scrollController = ScrollController();
  final FocusNode _searchFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this); // Tous, En cours, Traité, À revoir
    _tabController.addListener(_handleTabSelection);
    _searchFocusNode.addListener(_handleFocusChange);
    _loadDocuments();
  }

  @override
  void dispose() {
    _tabController.removeListener(_handleTabSelection);
    _tabController.dispose();
    _searchController.dispose();
    _scrollController.dispose();
    _searchFocusNode.removeListener(_handleFocusChange);
    _searchFocusNode.dispose();
    super.dispose();
  }

  void _handleFocusChange() {
    if (mounted) {
      setState(() {
        _isSearchFocused = _searchFocusNode.hasFocus;
      });
    }
  }

  void _handleTabSelection() {
    if (_tabController.indexIsChanging || !mounted) return;
    String newFilter;
    switch(_tabController.index) {
      case 0: newFilter = 'tous'; break;
      case 1: newFilter = 'en_cours'; break;
      case 2: newFilter = 'traite'; break;
      case 3: newFilter = 'a_revoir'; break;
      default: newFilter = 'tous';
    }
    if (_currentStatusFilter != newFilter) {
      if(mounted) setState(() { _currentStatusFilter = newFilter; });
      _applyFilters();
    }
  }

  void _applyFilters() {
    if (!mounted) return;
    final String searchQuery = _searchController.text.toLowerCase().trim();
    if(mounted) {
      setState(() {
        _filteredDocuments = _allDocuments.where((doc) {
          final statusMatch = (_currentStatusFilter == 'tous') || (doc.status == _currentStatusFilter);
          final typeMatch = (_currentTypeFilter == 'tous_types') ||
                              (_currentTypeFilter == 'facture' && doc.type.contains('facture')) ||
                              (_currentTypeFilter == 'bon_livraison' && doc.type == 'bon_livraison');
          final searchMatch = searchQuery.isEmpty ||
                              doc.fileName.toLowerCase().contains(searchQuery) ||
                              doc.typeFormatted.toLowerCase().contains(searchQuery) ||
                              (doc.entrepriseNom?.toLowerCase().contains(searchQuery) ?? false);
          return statusMatch && typeMatch && searchMatch;
        }).toList()
        ..sort((a, b) => _sortAscending ? a.uploadedAt.compareTo(b.uploadedAt) : b.uploadedAt.compareTo(a.uploadedAt));
      });
    }
  }

  Future<void> _loadDocuments() async {
    if (!mounted) return;
    if(mounted) setState(() { _isLoading = true; _errorMessage = null; });
    try {
      final documents = await fetchDocuments();
      if (mounted) {
        setState(() { 
          _allDocuments = documents;
          _isLoading = false; 
        });
        _applyFilters(); 
      }
    } catch (e) {
      if (mounted) setState(() { _errorMessage = e.toString().replaceFirst("Exception: ", ""); _isLoading = false; });
    }
  }

  void _showCustomSnackBar({
    required BuildContext context,
    required String message,
    required Color backgroundColor,
    required IconData icon,
    Duration duration = const Duration(seconds: 4) // Durée par défaut
  }) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(icon, color: Colors.white, size: 22),
            const SizedBox(width: 12),
            Expanded(child: Text(message, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500, fontSize: 14.5))),
          ],
        ),
        backgroundColor: backgroundColor,
        behavior: SnackBarBehavior.floating,
        elevation: 4.0,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: duration,
      ),
    );
  }

  Future<String?> _downloadFileToTemp(DocumentInfo doc, BuildContext contextForSnackBar) async {
    if (!mounted) return null;
     _showCustomSnackBar(
      context: contextForSnackBar, 
      message: 'Téléchargement de "${doc.fileName}"...', 
      backgroundColor: _accentColor, 
      icon: CupertinoIcons.cloud_download_fill,
      duration: const Duration(seconds: 60)
    );

    String? token = await getAuthToken();
    if (token == null || token.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(contextForSnackBar).hideCurrentSnackBar();
        _showCustomSnackBar(context: contextForSnackBar, message: "Token d'authentification manquant.", backgroundColor: _errorColor, icon: CupertinoIcons.xmark_octagon_fill);
      }
      return null;
    }

    final dio = Dio();
    final url = '$API_BASE_URL/documents/${doc.id}/download';
    try {
      final response = await dio.get(url, options: Options(headers: {'Authorization': 'Bearer $token', 'Accept': 'application/octet-stream'}, responseType: ResponseType.bytes));
      if (!mounted) return null;
      ScaffoldMessenger.of(contextForSnackBar).hideCurrentSnackBar();
      if (response.statusCode == 200 && response.data != null) {
        final directory = await getTemporaryDirectory();
        final localFilePath = '${directory.path}/${doc.fileName}';
        await File(localFilePath).writeAsBytes(response.data);
        return localFilePath;
      } else {
        _showCustomSnackBar(context: contextForSnackBar, message: 'Échec du téléchargement: ${response.statusCode}', backgroundColor: _errorColor, icon: CupertinoIcons.exclamationmark_triangle_fill);
        return null;
      }
    } on DioException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(contextForSnackBar).hideCurrentSnackBar();
        String errorMessage = "Erreur réseau.";
        if (e.response != null) {
          if (e.response?.statusCode == 401) errorMessage = "Session expirée.";
          else if (e.response?.statusCode == 403) errorMessage = "Accès non autorisé.";
          else if (e.response?.statusCode == 404) errorMessage = "Document non trouvé.";
          else errorMessage = "Erreur serveur (${e.response?.statusCode}).";
        }
        _showCustomSnackBar(context: contextForSnackBar, message: errorMessage, backgroundColor: _errorColor, icon: CupertinoIcons.wifi_slash);
      }
      return null;
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(contextForSnackBar).hideCurrentSnackBar();
        _showCustomSnackBar(context: contextForSnackBar, message: 'Erreur inconnue de téléchargement.', backgroundColor: _errorColor, icon: CupertinoIcons.question_circle_fill);
      }
      return null;
    }
  }

  Future<void> _viewDocument(DocumentInfo doc) async {
    if (!mounted) return;
    final BuildContext currentContext = context;
    _showCustomSnackBar(context: currentContext, message: 'Ouverture de "${doc.fileName}"...', backgroundColor: _accentColor, icon: CupertinoIcons.doc_text_search, duration: const Duration(seconds: 2));
    final String? localFilePath = await _downloadFileToTemp(doc, currentContext);
    if (!mounted) return;
    if (localFilePath != null) {
      try {
        final result = await OpenFilex.open(localFilePath);
        if (result.type != ResultType.done) {
           _showCustomSnackBar(context: currentContext, message: 'Impossible d\'ouvrir: ${result.message}', backgroundColor: _warningColor, icon: CupertinoIcons.exclamationmark_bubble_fill);
        }
      } catch (e) {
        _showCustomSnackBar(context: currentContext, message: 'Erreur d\'ouverture du fichier.', backgroundColor: _errorColor, icon: CupertinoIcons.xmark_octagon_fill);
      }
    }
  }

  Future<void> _downloadDocument(DocumentInfo doc) async {
    if (!mounted) return;
    final BuildContext currentContext = context;
    final String? localFilePath = await _downloadFileToTemp(doc, currentContext);
    if (!mounted) return;
    if (localFilePath != null) {
      _showCustomSnackBar(context: currentContext, message: '"${doc.fileName}" téléchargé.', backgroundColor: _successColor, icon: CupertinoIcons.check_mark_circled_solid);
    }
  }
  
  Future<void> _showRenameDialog(DocumentInfo doc) async { 
    if (!mounted) return;
    final TextEditingController renameController = TextEditingController(text: doc.fileName);
    final formKey = GlobalKey<FormState>();
    final BuildContext currentContext = context;

    String? newName = await showDialog<String>(
      context: currentContext,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          backgroundColor: _cardColor,
          elevation: 8,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          titlePadding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          actionsPadding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
          title: Row(
            children: [
              Icon(CupertinoIcons.pencil_ellipsis_rectangle, color: _primaryColor, size: 26),
              const SizedBox(width: 12),
              Text('Renommer', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w600, color: _textColorPrimary))
            ]
          ),
          content: Form(
            key: formKey,
            child: TextFormField(
              controller: renameController,
              autofocus: true,
              style: TextStyle(fontSize: 15, color: _textColorPrimary),
              decoration: InputDecoration(
                hintText: "Nouveau nom du fichier",
                hintStyle: TextStyle(color: _textColorSecondary.withOpacity(0.6)),
                filled: true,
                fillColor: _scaffoldBgColor,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: Colors.grey.shade300, width: 1)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: Colors.grey.shade300, width: 1)),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: _primaryColor, width: 1.5)),
                prefixIcon: Icon(CupertinoIcons.doc_on_clipboard, color: _textColorSecondary, size: 20),
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
              ),
              validator: (v) => (v==null||v.trim().isEmpty)?'Nom requis.':(!v.contains('.'))?'Extension requise.':null
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Annuler', style: TextStyle(fontWeight: FontWeight.w600, color: _neutralColor, fontSize: 14.5)),
              onPressed: () => Navigator.of(dialogContext).pop(),
              style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
            ),
            ElevatedButton.icon(
              icon: const Icon(CupertinoIcons.check_mark_circled, size: 18),
              label: const Text('Renommer', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14.5)),
              style: ElevatedButton.styleFrom(
                backgroundColor: _primaryColor, foregroundColor: Colors.white, elevation: 1,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              onPressed: () { if (formKey.currentState!.validate()) Navigator.of(dialogContext).pop(renameController.text.trim()); }
            )
          ],
        );
      },
    );
    if (!mounted || newName == null || newName.trim().isEmpty) return;
    if (newName.trim() == doc.fileName) {
      _showCustomSnackBar(context: currentContext, message: 'Le nouveau nom est identique.', backgroundColor: _warningColor, icon: CupertinoIcons.info_circle_fill);
      return;
    }
    _showCustomSnackBar(context: currentContext, message: 'Renommage en cours...', backgroundColor: _accentColor, icon: CupertinoIcons.time, duration: const Duration(seconds: 30));
    try {
      final result = await renameDocument(documentId: doc.id, nouveauNomFichier: newName.trim());
      if (!mounted) return; 
      ScaffoldMessenger.of(currentContext).hideCurrentSnackBar(); 
      if (result != null && result.containsKey('document')) { 
         _showCustomSnackBar(context: currentContext, message: 'Renommé avec succès !', backgroundColor: _successColor, icon: CupertinoIcons.check_mark_circled_solid);
        _loadDocuments(); 
      } else { 
         _showCustomSnackBar(context: currentContext, message: result?['message'] as String? ?? 'Échec du renommage.', backgroundColor: _errorColor, icon: CupertinoIcons.xmark_octagon_fill);
      }
    } catch (e) { 
      if (!mounted) return; 
      ScaffoldMessenger.of(currentContext).hideCurrentSnackBar(); 
      _showCustomSnackBar(context: currentContext, message: 'Erreur: ${e.toString().replaceFirst("Exception: ", "")}', backgroundColor: _errorColor, icon: CupertinoIcons.xmark_octagon_fill);
    }
  }

  Future<void> _shareDocument(DocumentInfo doc) async {
    if (!mounted) return;
    final BuildContext currentContext = context;
     _showCustomSnackBar(context: currentContext, message: 'Préparation du partage...', backgroundColor: _accentColor, icon: CupertinoIcons.share_up, duration: const Duration(seconds: 2));
    final String? localFilePath = await _downloadFileToTemp(doc, currentContext);
    if (!mounted) return;
    if (localFilePath != null) {
      try {
        final xfile = XFile(localFilePath);
        await Share.shareXFiles([xfile], text: "Document: ${doc.fileName}", subject: 'Document: ${doc.fileName}');
      } catch (e) {
        if (mounted) _showCustomSnackBar(context: currentContext, message: 'Erreur de partage.', backgroundColor: _errorColor, icon: CupertinoIcons.xmark_octagon_fill);
      }
    }
  }

  Future<void> _deleteDocument(DocumentInfo doc) async { 
    if (!mounted) return;
    final BuildContext currentContext = context;
    bool? confirmDelete = await showDialog<bool>(
      context: currentContext,
      builder: (BuildContext dialogContext) => AlertDialog(
        backgroundColor: _cardColor, elevation: 8, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(children: [Icon(CupertinoIcons.trash_fill, color: _errorColor, size: 26), const SizedBox(width:12), Text('Supprimer', style: TextStyle(color: _textColorPrimary, fontWeight: FontWeight.w600, fontSize: 19))]),
        content: Text('Voulez-vous vraiment supprimer "${doc.fileName}" ?', style: TextStyle(color: _textColorSecondary, fontSize: 15)),
        actions: <Widget>[
          TextButton(child: Text('Annuler', style: TextStyle(fontWeight: FontWeight.w600, color: _neutralColor, fontSize: 14.5)), onPressed: () => Navigator.of(dialogContext).pop(false), style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)))), 
          TextButton(child: Text('Supprimer', style: TextStyle(color: _errorColor, fontWeight: FontWeight.w600, fontSize: 14.5)), onPressed: () => Navigator.of(dialogContext).pop(true), style: TextButton.styleFrom(backgroundColor: _errorColor.withOpacity(0.1) ,padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)))),
        ]
      ),
    );
    if (confirmDelete != true || !mounted) return;
    _showCustomSnackBar(context: currentContext, message: 'Suppression en cours...', backgroundColor: _accentColor, icon: CupertinoIcons.time, duration: const Duration(seconds: 30));
    try {
      bool success = await deleteDocumentApi(doc.id);
      if (!mounted) return;
      ScaffoldMessenger.of(currentContext).hideCurrentSnackBar();
      if (success) { 
        _showCustomSnackBar(context: currentContext, message: '"${doc.fileName}" supprimé.', backgroundColor: _successColor, icon: CupertinoIcons.check_mark_circled_solid);
        _loadDocuments();
      } else { 
        _showCustomSnackBar(context: currentContext, message: 'Échec de la suppression.', backgroundColor: _errorColor, icon: CupertinoIcons.xmark_octagon_fill);
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(currentContext).hideCurrentSnackBar();
      _showCustomSnackBar(context: currentContext, message: 'Erreur: ${e.toString().replaceFirst("Exception: ", "")}', backgroundColor: _errorColor, icon: CupertinoIcons.xmark_octagon_fill);
    }
  }

  
  
  
  
  IconData _getFileIcon(String fileName) { 
    final ext = fileName.split('.').last.toLowerCase();
    if (ext == 'pdf') return CupertinoIcons.doc_richtext;
    if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'].contains(ext)) return CupertinoIcons.photo_fill_on_rectangle_fill;
    if (['doc', 'docx'].contains(ext)) return CupertinoIcons.doc_text_fill;
    if (['xls', 'xlsx'].contains(ext)) return CupertinoIcons.table_fill;
    if (['ppt', 'pptx'].contains(ext)) return CupertinoIcons.tv_music_note_fill; // Un peu différent
    if (['zip', 'rar', '7z'].contains(ext)) return CupertinoIcons.archivebox_fill;
    return CupertinoIcons.doc_fill;
  }

  Color _getFileIconColor(String fileName) { 
    final ext = fileName.split('.').last.toLowerCase();
    if (ext == 'pdf') return const Color(0xFFF44336); 
    if (['jpg', 'jpeg', 'png', 'gif'].contains(ext)) return const Color(0xFF4CAF50); 
    if (['doc', 'docx'].contains(ext)) return const Color(0xFF2196F3); 
    if (['xls', 'xlsx'].contains(ext)) return const Color(0xFF4CAF50);
    if (['ppt', 'pptx'].contains(ext)) return const Color(0xFFFF9800);
    return _neutralColor;
  }

  Color _getStatusColor(String status) { 
    switch (status) { 
      case 'en_cours': return _warningColor; 
      case 'traite': return _successColor; 
      case 'a_revoir': return _errorColor; 
      default: return _neutralColor; 
    }
  }
  String _formatStatus(String status) { 
    switch (status) { 
      case 'en_cours': return 'En Cours'; 
      case 'traite': return 'Traité'; 
      case 'a_revoir': return 'À Revoir'; 
      default: return status.isNotEmpty ? status.capitalize() : 'N/A'; 
    }
  }
  
  Widget _buildEmptyState() { 
    bool noFiltersApplied = _searchController.text.isEmpty && _currentTypeFilter == 'tous_types' && _currentStatusFilter == 'tous';
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.all(32.0), 
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center, 
        children: [ 
          Icon(noFiltersApplied ? CupertinoIcons.doc_text_search : CupertinoIcons.search_circle_fill, size: 80, color: _neutralColor.withOpacity(0.3)), 
          const SizedBox(height: 20), 
          Text(
            noFiltersApplied ? 'Aucun document' : 'Aucun résultat', 
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: _textColorPrimary.withOpacity(0.8)), 
            textAlign: TextAlign.center,
          ), 
          const SizedBox(height: 10), 
          Text(
            noFiltersApplied ? 'Vos documents apparaîtront ici une fois téléversés.' : 'Essayez de modifier vos filtres ou votre recherche.', 
            style: TextStyle(fontSize: 15, color: _textColorSecondary.withOpacity(0.8)), 
            textAlign: TextAlign.center,
          ), 
          if (!noFiltersApplied) 
            Padding(
              padding: const EdgeInsets.only(top: 24), 
              child: ElevatedButton.icon(
                icon: const Icon(CupertinoIcons.clear_circled, size: 18), 
                label: const Text('Effacer les filtres'), 
                style: ElevatedButton.styleFrom(
                  backgroundColor: _primaryColor.withOpacity(0.1), 
                  foregroundColor: _primaryColor,
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20),),
                ), 
                onPressed: () { 
                  _searchController.clear(); 
                  if(mounted) {
                    setState(() { _currentTypeFilter = 'tous_types'; _tabController.animateTo(0);});
                  }
                  _applyFilters(); 
                },
              ),
            ), 
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.all(32.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center, 
        children: [ 
          Icon(CupertinoIcons.wifi_slash, size: 80, color: _errorColor.withOpacity(0.6)), 
          const SizedBox(height: 20), 
          Text('Oops !', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: _errorColor),), 
          const SizedBox(height: 10), 
          Text(_errorMessage ?? 'Impossible de charger les documents. Vérifiez votre connexion et réessayez.', style: TextStyle(fontSize: 15, color: _textColorSecondary.withOpacity(0.8)), textAlign: TextAlign.center,), 
          const SizedBox(height: 24), 
          ElevatedButton.icon(
            icon: const Icon(Icons.refresh_rounded, size: 20), 
            label: const Text('Réessayer'), 
            style: ElevatedButton.styleFrom(
              backgroundColor: _primaryColor, foregroundColor: Colors.white, 
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12), 
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25),),
              textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)
            ), 
            onPressed: _loadDocuments,
          ), 
        ],
      ),
    );
  }

  Widget _buildBottomNavigationBar(BuildContext context, int currentIndex) { 
    return Container(
  
     decoration: BoxDecoration(
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.05),
          blurRadius: 10,
          offset: const Offset(0, -5),
        ),
      ],
    ),
    child: ClipRRect(
      borderRadius: const BorderRadius.only(
        topLeft: Radius.circular(20),
        topRight: Radius.circular(20),
      ),
      child: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFF2196F3),
        unselectedItemColor: Colors.grey,
        currentIndex: currentIndex,
        backgroundColor: Colors.white,
        elevation: 10,
        selectedLabelStyle: const TextStyle(
          fontWeight: FontWeight.w500,
          fontSize: 12,
        ),
        unselectedLabelStyle: const TextStyle(fontSize: 12),
        onTap: (index) { 
          if (index == currentIndex) return; 
          String routeName; 
          switch (index) { 
            case 0: routeName = '/home'; break; 
            case 1: routeName = '/upload'; break; 
            case 2: routeName = '/documents'; break; 
            case 3: routeName = '/profile'; break; 
            default: return; 
          } 
          Navigator.pushReplacementNamed(context, routeName);
        }, 
           items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home_outlined, size: 24), activeIcon: Icon(Icons.home_rounded, size: 26), label: 'Accueil'),
            BottomNavigationBarItem(icon: Icon(Icons.cloud_upload_outlined, size: 24), activeIcon: Icon(Icons.add_circle_rounded, size:26), label: 'Déposer'),
            BottomNavigationBarItem(icon: Icon(Icons.folder_copy_outlined, size: 24), activeIcon: Icon(Icons.folder_copy_rounded, size: 26), label: 'Documents'),
            BottomNavigationBarItem(icon: Icon(Icons.person_outline_rounded, size: 24), activeIcon: Icon(Icons.person_rounded, size: 26), label: 'Profil'),
          ],
      ),
    ),
    );
  }

  Widget _buildTypeFilterChip(String label, String filterValue) {
    final bool isSelected = _currentTypeFilter == filterValue;
    return FilterChip(
      label: Text(label, style: TextStyle(fontWeight: isSelected ? FontWeight.bold : FontWeight.w500, fontSize: 13.5)),
      selected: isSelected,
      onSelected: (selected) {
         if (mounted) { setState(() { _currentTypeFilter = filterValue; }); _applyFilters(); }
      },
      backgroundColor: _scaffoldBgColor,
      selectedColor: _primaryColor.withOpacity(0.1),
      labelStyle: TextStyle(color: isSelected ? _primaryColor : _textColorSecondary.withOpacity(0.9)),
      shape: StadiumBorder(side: BorderSide(color: isSelected ? _primaryColor.withOpacity(0.5) : Colors.grey.shade300, width: 1)),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      showCheckmark: false,
      elevation: isSelected ? 0.5 : 0,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _scaffoldBgColor,
      appBar: AppBar(
        backgroundColor: _cardColor, 
        elevation: 0.8, 
        centerTitle: false, // Titre à gauche pour un look plus moderne
        titleSpacing: 16.0,
        title: Text(
          'Mes Documents', 
          style: TextStyle(fontWeight: FontWeight.bold, color: _textColorPrimary, fontSize: 24)
        ),
        iconTheme: IconThemeData(color: _textColorPrimary),
        actions: [
          IconButton(
            icon: Icon(_sortAscending ? CupertinoIcons.sort_up : CupertinoIcons.sort_down, color: _neutralColor, size: 22),
            tooltip: _sortAscending ? "Plus anciens" : "Plus récents",
            onPressed: () { if (mounted) { setState(() { _sortAscending = !_sortAscending; }); _applyFilters(); }}
          ),
          IconButton(
            icon: Icon(CupertinoIcons.refresh_thick, color: _neutralColor, size: 22),
            onPressed: _isLoading ? null : _loadDocuments,
            tooltip: 'Rafraîchir',
          ),
          const SizedBox(width: 8),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(kToolbarHeight), 
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 6.0), 
            decoration: BoxDecoration(color: _cardColor, border: Border(bottom: BorderSide(color: Colors.grey.shade200, width: 0.8))),
            child: TabBar(
              controller: _tabController,
              isScrollable: true, 
              indicator: UnderlineTabIndicator(borderSide: BorderSide(color: _primaryColor, width: 3.0), insets: EdgeInsets.symmetric(horizontal: 16.0)),
              indicatorSize: TabBarIndicatorSize.label, // Indicateur sous le label seulement
              labelColor: _primaryColor,
              unselectedLabelColor: _neutralColor.withOpacity(0.8),
              labelPadding: const EdgeInsets.symmetric(horizontal: 18), 
              labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 0.1),
              unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13.5),
              tabs: const [ Tab(text: 'Tous'), Tab(text: 'En Attente'), Tab(text: 'Validés'), Tab(text: 'Rejetés'), ], // Noms plus engageants
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 12.0),
            color: _cardColor, // Couleur de fond pour cette section, peut être _scaffoldBgColor aussi
            child: Column(
              children: [
                TextField(
                  controller: _searchController,
                  focusNode: _searchFocusNode,
                  style: TextStyle(fontSize: 15, color: _textColorPrimary),
                  decoration: InputDecoration(
                    hintText: 'Rechercher un document...',
                    hintStyle: TextStyle(color: _textColorSecondary.withOpacity(0.6), fontSize: 14.5),
                    prefixIcon: Padding( padding: const EdgeInsets.only(left: 14.0, right: 10.0), child: Icon(CupertinoIcons.search, color: _searchFocusNode.hasFocus ? _primaryColor : _neutralColor.withOpacity(0.6), size: 20)),
                    suffixIcon: _searchController.text.isNotEmpty ? IconButton(icon: Icon(CupertinoIcons.clear_thick_circled, color: _neutralColor.withOpacity(0.5), size: 18), onPressed: () { _searchController.clear(); _applyFilters(); _searchFocusNode.unfocus(); }) : null,
                    filled: true, 
                    fillColor: _scaffoldBgColor,
                    contentPadding: const EdgeInsets.symmetric(vertical: 14.0), 
                    border: OutlineInputBorder( borderRadius: BorderRadius.circular(12.0), borderSide: BorderSide.none,),
                    enabledBorder: OutlineInputBorder( borderRadius: BorderRadius.circular(12.0), borderSide: BorderSide(color: Colors.grey.shade300, width: 1.0),),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12.0), borderSide: BorderSide(color: _primaryColor, width: 1.5),),
                  ),
                  onChanged: (value) => _applyFilters(),
                ),
                const SizedBox(height: 12),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  child: Row(
                    children: [
                      _buildTypeFilterChip('Tous les types', 'tous_types'), const SizedBox(width: 8),
                      _buildTypeFilterChip('Factures', 'facture'), const SizedBox(width: 8),
                      _buildTypeFilterChip('Bons de livraison', 'bon_livraison'),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: _loadDocuments, color: _primaryColor, backgroundColor: _cardColor,
              child: _isLoading
                  ? Center(child: CupertinoActivityIndicator(radius: 16, color: _primaryColor))
                  : _errorMessage != null
                      ? _buildErrorState()
                      : _filteredDocuments.isEmpty
                          ? _buildEmptyState()
                          : ListView.builder(
                              controller: _scrollController, 
                              padding: const EdgeInsets.only(top: 8.0, bottom: 16.0),
                              itemCount: _filteredDocuments.length,
                              itemBuilder: (context, index) {
                                final doc = _filteredDocuments[index];
                                return DocumentCardWidget( 
                                  key: ValueKey(doc.id),
                                  doc: doc,
                                  getFileIcon: _getFileIcon,
                                  getFileIconColor: _getFileIconColor,
                                  getStatusColor: _getStatusColor,
                                  formatStatus: _formatStatus,
                                  primaryColor: _primaryColor,
                                  textColorPrimary: _textColorPrimary,
                                  textColorSecondary: _textColorSecondary,
                                  cardColor: _cardColor,
                                  onView: () => _viewDocument(doc),
                                  onDownload: () => _downloadDocument(doc), 
                                  onRename: () => _showRenameDialog(doc),
                                  onShare: () => _shareDocument(doc), 
                                  onDelete: () => _deleteDocument(doc),
                                );
                              },
                            ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNavigationBar(context, 2), // Index 2 pour 'Documents'
    );
  }
}