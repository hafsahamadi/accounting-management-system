import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';
import 'package:flutter/cupertino.dart';

// Gardez ces fonctions et constantes globales
Future<String?> getAuthToken() async {
  const storage = FlutterSecureStorage();
  return await storage.read(key: 'token');
}
const String API_BASE_URL = "http://192.168.1.78:8000/api"; 
const String WELCOME_NOTIFICATION_KEY = 'last_welcome_notification_time_profile';

// Les modèles restent identiques
class UserProfileInfo {
  final String companyName;
  final String email;
  final String phone;
  final String address;
  final String initials;

  UserProfileInfo({
    required this.companyName,
    required this.email,
    required this.phone,
    required this.address,
    required this.initials,
  });

  factory UserProfileInfo.fromJson(Map<String, dynamic> json) {
    String name = json['nom_entreprise'] ?? json['name'] ?? 'N/A';
    String initials = "N/A";
    if (name != 'N/A' && name.isNotEmpty) {
      List<String> parts = name.split(' ');
      if (parts.isNotEmpty) {
        initials = parts.map((p) => p.isNotEmpty ? p[0].toUpperCase() : '').take(3).join();
         if (initials.isEmpty && name.length >= 2) initials = name.substring(0,2).toUpperCase();
         else if (initials.isEmpty && name.isNotEmpty) initials = name[0].toUpperCase();
      } else if (name.isNotEmpty) {
        initials = name[0].toUpperCase();
      }
    }

    return UserProfileInfo(
      companyName: name,
      email: json['email'] ?? 'Non spécifié',
      phone: json['telephone'] ?? 'Non spécifié',
      address: json['adresse'] ?? 'Non spécifiée',
      initials: initials,
    );
  }
}

class ProfileActivityInfo {
  final int totalDocumentsDeposited;
  final String? lastDepositFileName;
  final DateTime? lastDepositDate;

  ProfileActivityInfo({
    required this.totalDocumentsDeposited,
    this.lastDepositFileName,
    this.lastDepositDate,
  });

  factory ProfileActivityInfo.fromJson(Map<String, dynamic> json) {
    DateTime? lastDate;
    if (json['last_deposit'] != null && json['last_deposit']['date'] != null) {
      lastDate = DateTime.tryParse(json['last_deposit']['date']);
    }
    return ProfileActivityInfo(
      totalDocumentsDeposited: json['total_documents_deposited'] ?? 0,
      lastDepositFileName: json['last_deposit']?['file_name'],
      lastDepositDate: lastDate,
    );
  }
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);
  

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  int _currentIndex = 3; 
  final _routes = ['/home', '/upload', '/documents', '/profile']; 

  UserProfileInfo? _profileInfo;
  ProfileActivityInfo? _activityInfo;

  bool _isLoadingProfile = true;
  bool _isLoadingActivity = true;
  String? _errorProfile;
  String? _errorActivity;

  final Dio _dio = Dio();

  @override
  void initState() {
    super.initState();
    _loadProfileData();
  }

  Future<void> _loadProfileData() async {
    if (!mounted) return;
    setState(() {
      _isLoadingProfile = true;
      _isLoadingActivity = true;
      _errorProfile = null;
      _errorActivity = null;
    });
    await Future.wait([
      _fetchUserProfile(),
      _fetchProfileActivity(),
    ]);
  }

  Future<void> _fetchUserProfile() async {
    final token = await getAuthToken();
    if (!mounted) return;
    if (token == null) {
      setState(() { _isLoadingProfile = false; _errorProfile = "Authentification requise."; });
      // NOUVEAU: Si pas de token, rediriger vers login
      _redirectToLoginIfNeeded(token);
      return;
    }
    try {
      final response = await _dio.get(
        '$API_BASE_URL/profile',
        options: Options(headers: {'Authorization': 'Bearer $token', 'Accept': 'application/json'}),
      );
      if (!mounted) return;
      if (response.statusCode == 200 && response.data != null) {
        setState(() {
          _profileInfo = UserProfileInfo.fromJson(response.data);
          _isLoadingProfile = false;
        });
      } else {
        setState(() { _isLoadingProfile = false; _errorProfile = "Erreur ${response.statusCode}"; });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() { _isLoadingProfile = false; _errorProfile = "Erreur de connexion (profil)"; });
      print("Erreur fetchUserProfile: $e");
    }
  }

  Future<void> _fetchProfileActivity() async {
    final token = await getAuthToken();
    if (!mounted) return;
    if (token == null) {
      setState(() { _isLoadingActivity = false; _errorActivity = "Authentification requise."; });
      // NOUVEAU: Si pas de token, rediriger vers login
      _redirectToLoginIfNeeded(token);
      return;
    }
    try {
      final response = await _dio.get(
        '$API_BASE_URL/documents/recent-documents',
        options: Options(headers: {'Authorization': 'Bearer $token', 'Accept': 'application/json'}),
      );
      if (!mounted) return;
      if (response.statusCode == 200 && response.data != null) {
        setState(() {
          _activityInfo = ProfileActivityInfo.fromJson(response.data);
          _isLoadingActivity = false;
        });
      } else {
        setState(() { _isLoadingActivity = false; _errorActivity = "Erreur ${response.statusCode}"; });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() { _isLoadingActivity = false; _errorActivity = "Erreur de connexion (activité)"; });
      print("Erreur fetchProfileActivity: $e");
    }
  }

  // NOUVEAU: Fonction pour vérifier le token et rediriger si nécessaire
  void _redirectToLoginIfNeeded(String? token) {
    if (token == null && mounted) {
      print("Token null détecté - Redirection vers login");
      // Utiliser Future.delayed pour éviter de naviguer pendant un setState ou un build
      Future.delayed(Duration.zero, () {
        _navigateToLogin();
      });
    }
  }

  // MODIFIÉ: Fonction de navigation vers login améliorée
  void _navigateToLogin() {
    if (!mounted) {
      print("_navigateToLogin: Widget non monté, navigation annulée.");
      return;
    }
    print("_navigateToLogin: Tentative de navigation vers '/'.");
    
    // Utiliser pushNamedAndRemoveUntil pour effacer TOUT l'historique de navigation
    Navigator.of(context, rootNavigator: true).pushNamedAndRemoveUntil(
      '/',
      (_) => false, // Ce prédicat garantit que TOUTES les routes sont supprimées
    );
    
    print("_navigateToLogin: Navigation vers '/' tentée.");
  }

  // MODIFIÉ: Fonction de déconnexion améliorée
  Future<void> _logout() async {
    print("Logout: Début");
    
    final token = await getAuthToken();
    print("Logout: Token obtenu: ${token != null ? 'Présent' : 'Null'}");

    // Si pas de token, on considère l'utilisateur comme déconnecté
    if (token == null) {
      print("Logout: Token déjà null.");
      if (mounted) {
        _navigateToLogin();
      }
      return;
    }

    // Afficher un dialogue de confirmation
    final bool confirmLogout = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Row(children: [Icon(CupertinoIcons.square_arrow_left, color: Colors.orange.shade700), SizedBox(width: 10), const Text('Déconnexion')]),
          content: const Text('Êtes-vous sûr de vouloir vous déconnecter ?'),
          actions: <Widget>[
            TextButton(
              child: const Text('Annuler', style: TextStyle(fontWeight: FontWeight.w500)),
              onPressed: () => Navigator.of(dialogContext).pop(false),
            ),
            TextButton(
              child: Text('Se déconnecter', style: TextStyle(color: Colors.red.shade700, fontWeight: FontWeight.bold)),
              onPressed: () => Navigator.of(dialogContext).pop(true),
            ),
          ],
        );
      },
    ) ?? false;

    print("Logout: Confirmation: $confirmLogout");
    if (!confirmLogout) return;

    // Afficher un indicateur de chargement (SnackBar)
    if (mounted) {
      print("Logout: Affichage du SnackBar de chargement");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(children: const [CircularProgressIndicator(valueColor: AlwaysStoppedAnimation(Colors.white)), SizedBox(width:15), Text("Déconnexion en cours...")]),
          backgroundColor: Theme.of(context).primaryColor,
          duration: const Duration(seconds: 5),
        )
      );
    }

    // Tenter la déconnexion API
    try {
      print("Logout: Tentative d'appel API /logout");
      await _dio.post(
        '$API_BASE_URL/logout',
        options: Options(headers: {'Authorization': 'Bearer $token', 'Accept': 'application/json'}),
      );
      print("Logout: Appel API /logout terminé.");
    } catch (e) {
      print("Logout: Erreur lors de la déconnexion API: $e");
      // On continue malgré l'erreur API, car on veut nettoyer le stockage local
    }

    // Opérations de nettoyage locales
    print("Logout: Nettoyage du stockage local.");
    const storage = FlutterSecureStorage();
    try {
      await storage.delete(key: 'token');
      await storage.delete(key: 'userId');
      print("Logout: Token supprimé du FlutterSecureStorage.");
      
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(WELCOME_NOTIFICATION_KEY);
      print("Logout: Préférences nettoyées.");
    } catch (e) {
      print("Logout: Erreur pendant le nettoyage du stockage: $e");
    }

    // Navigation finale - MODIFIÉ: Plus robuste avec une vérification supplémentaire
    if (mounted) {
      print("Logout: Widget monté, masquage du SnackBar et navigation vers login.");
      ScaffoldMessenger.of(context).hideCurrentSnackBar();
      
      // NOUVEAU: Vérifier si le widget est toujours dans l'arbre
      if (ModalRoute.of(context) != null && ModalRoute.of(context)!.isCurrent) {
        _navigateToLogin();
      } else {
        print("Logout: Le widget n'est plus dans l'arbre de navigation actuel.");
        // Tentative alternative de navigation
        Navigator.of(context, rootNavigator: true).pushNamedAndRemoveUntil('/', (_) => false);
      }
    } else {
      print("Logout: ERREUR - Le widget ProfilePage n'est plus monté au moment de la navigation finale !");
    }
  }

  void _onItemTapped(int index) {
    if (index == _currentIndex && ModalRoute.of(context)?.settings.name == _routes[index]) return; 
    Navigator.pushReplacementNamed(context, _routes[index]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text('Mon Profil', style: TextStyle(color: Color(0xFF263238), fontWeight: FontWeight.bold, fontSize: 20)),
        elevation: 0.5,
        backgroundColor: Colors.white,
        centerTitle: false,
        iconTheme: const IconThemeData(color: Color(0xFF263238)),
      ),
      body: RefreshIndicator(
        onRefresh: _loadProfileData,
        color: Color(0xFF2196F3),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildHeader(context),
              const SizedBox(height: 24),
              _buildSubscriptionSection(context),
              const SizedBox(height: 24),
              _buildPersonalInfoSection(context),
              const SizedBox(height: 24),
              _buildActivitySection(context),
              const SizedBox(height: 24),
              _buildSettingsSection(context),
              const SizedBox(height: 30), 
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
   
     decoration: BoxDecoration(
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.05),
          blurRadius: 10,
          offset: const Offset(0, -5),
        ),
      ],
    ),
    child: ClipRRect(
      borderRadius: const BorderRadius.only(
        topLeft: Radius.circular(20),
        topRight: Radius.circular(20),
      ),
      child: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFF2196F3),
        unselectedItemColor: Colors.grey,
        currentIndex: 3,
        backgroundColor: Colors.white,
        elevation: 10,
        selectedLabelStyle: const TextStyle(
          fontWeight: FontWeight.w500,
          fontSize: 12,
        ),
        unselectedLabelStyle: const TextStyle(fontSize: 12),
          onTap: _onItemTapped, 
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home_outlined, size: 26), activeIcon: Icon(Icons.home_rounded, size: 28), label: 'Accueil'),
            BottomNavigationBarItem(icon: Icon(Icons.cloud_upload_outlined, size: 26), activeIcon: Icon(Icons.cloud_upload_rounded, size: 28), label: 'Déposer'),
            BottomNavigationBarItem(icon: Icon(Icons.folder_copy_outlined, size: 26), activeIcon: Icon(Icons.folder_copy_rounded, size: 28), label: 'Documents'),
            BottomNavigationBarItem(icon: Icon(Icons.person_outline_rounded, size: 26), activeIcon: Icon(Icons.person_rounded, size: 28), label: 'Profil'),
          ],
        ),
      ),
    ),
    );
  }

  // Les méthodes de construction de widgets restent identiques
  Widget _buildHeader(BuildContext context) {
    final theme = Theme.of(context).textTheme;
    if (_isLoadingProfile) {
      return Card(
        color: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), elevation: 2,
        child: Padding(padding: const EdgeInsets.symmetric(vertical: 24), child: Center(child: CircularProgressIndicator(color: Theme.of(context).primaryColor))),
      );
    }
    if (_errorProfile != null || _profileInfo == null) {
       return Card(
        color: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), elevation: 2,
        child: Padding(padding: const EdgeInsets.all(24), child: Text(_errorProfile ?? "Impossible de charger le profil.", textAlign: TextAlign.center, style: TextStyle(color: Colors.red.shade700))),
      );
    }
    return Card(
       color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 3, 
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20), 
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircleAvatar(
              radius: 52, 
              backgroundColor:Color.fromARGB(255, 230, 236, 240),
              child: Text(
                _profileInfo!.initials, 
                style: theme.displaySmall!.copyWith(
                  color: Color.fromARGB(255, 115, 166, 200), 
                  fontWeight: FontWeight.bold
                )
              ),
            ),
            const SizedBox(height: 20),
            Text(_profileInfo!.companyName, style: theme.headlineSmall!.copyWith(fontWeight: FontWeight.bold, color: Color(0xFF263238))),
            const SizedBox(height: 6),
            Text(_profileInfo!.email, style: theme.bodyMedium!.copyWith(color: Colors.grey.shade700, fontSize: 15)),
          ],
        ),
      ),
    );
  }

  Widget _buildSubscriptionSection(BuildContext context) {
    final theme = Theme.of(context).textTheme;
    return Card(
       color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Abonnement', style: theme.titleMedium!.copyWith(fontWeight: FontWeight.w600, color: Color(0xFF374151))),
            const Divider(height: 20, thickness: 0.8),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF2196F3),Color.fromARGB(255, 230, 236, 240)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                 boxShadow: [BoxShadow(color: Theme.of(context).primaryColor.withOpacity(0.3), blurRadius: 8, offset: Offset(0,4))]
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.verified_user_rounded, color: Colors.white, size: 22),
                      const SizedBox(width: 10),
                      Text('Abonnement Actif', style: TextStyle(color: Colors.white, fontSize: 16.5, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text('Plan Actuel : Premium Annuel', style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 14)),
                  const SizedBox(height: 4),
                  Text('Expire le : 31 Décembre 2025', style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 14)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: Icon(Icons.autorenew_rounded, size: 20),
                label: const Text('Gérer l\'abonnement', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                onPressed: () { /* TODO: Logique de renouvellement */ },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF2196F3), 
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14), 
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  elevation: 2,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPersonalInfoSection(BuildContext context) {
    final theme = Theme.of(context).textTheme;
     if (_isLoadingProfile) {
      return Card(elevation:0, color: Colors.transparent, child: Center(child: Padding(padding: const EdgeInsets.all(16.0), child: CupertinoActivityIndicator())));
    }
    if (_errorProfile != null || _profileInfo == null) {
      return Card(elevation:2, color: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), child: Padding(padding: const EdgeInsets.all(16), child: Text(_errorProfile ?? "Infos personnelles non disponibles.", style: TextStyle(color: Colors.red.shade700))));
    }
    return Card(
       color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Informations de l\'entreprise', style: theme.titleMedium!.copyWith(fontWeight: FontWeight.w600, color: Color(0xFF374151))),
            const Divider(height: 20, thickness: 0.8),
            _infoTile(CupertinoIcons.building_2_fill, 'Nom', _profileInfo!.companyName),
            _infoTile(CupertinoIcons.mail_solid, 'Email', _profileInfo!.email),
            _infoTile(CupertinoIcons.phone_fill, 'Téléphone', _profileInfo!.phone),
            _infoTile(CupertinoIcons.location_solid, 'Adresse', _profileInfo!.address),
          ],
        ),
      ),
    );
  }

  Widget _buildActivitySection(BuildContext context) {
    final theme = Theme.of(context).textTheme;
    if (_isLoadingActivity) {
      return Card(elevation:0, color: Colors.transparent, child: Center(child: Padding(padding: const EdgeInsets.all(16.0), child: CupertinoActivityIndicator())));
    }
     if (_errorActivity != null || _activityInfo == null) {
      return Card(elevation:2, color: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), child: Padding(padding: const EdgeInsets.all(16), child: Text(_errorActivity ?? "Activité non disponible.", style: TextStyle(color: Colors.red.shade700))));
    }

    String lastDepositDateFormatted = "N/A";
    if (_activityInfo!.lastDepositDate != null) {
      lastDepositDateFormatted = DateFormat('dd MMM yyyy, HH:mm', 'fr_FR').format(_activityInfo!.lastDepositDate!.toLocal());
    }

    return Card(
       color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Activité du compte', style: theme.titleMedium!.copyWith(fontWeight: FontWeight.w600, color: Color(0xFF374151))),
            const Divider(height: 20, thickness: 0.8),
            _activityTile(CupertinoIcons.doc_chart_fill, 'Documents déposés', _activityInfo!.totalDocumentsDeposited.toString()),
            const SizedBox(height: 8),
            _activityTile(CupertinoIcons.arrow_up_doc_fill, 'Dernier dépôt', _activityInfo!.lastDepositFileName ?? "Aucun", subtitle: _activityInfo!.lastDepositFileName != null ? lastDepositDateFormatted : null),
         
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () { Navigator.pushReplacementNamed(context, '/documents'); },
                 style: TextButton.styleFrom(foregroundColor: Theme.of(context).primaryColor, padding: EdgeInsets.symmetric(horizontal:0, vertical: 8)),
                child: const Text('Voir l\'historique complet', style: TextStyle(fontWeight: FontWeight.w600)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSettingsSection(BuildContext context) {
    return Card(
       color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 0), 
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal:16.0, vertical: 8.0),
              child: Text('Paramètres & Sécurité', style: Theme.of(context).textTheme.titleMedium!.copyWith(fontWeight: FontWeight.w600, color: Color(0xFF374151))),
            ),
            const Divider(height: 1, thickness: 0.8, indent: 16, endIndent: 16),
            _settingsButton(Icons.edit_rounded, 'Modifier mes informations', onTap: () { /* TODO */ }),
            _settingsButton(CupertinoIcons.lock_shield, 'Changer de mot de passe', onTap: () { /* TODO */ }),
            _settingsButton(CupertinoIcons.square_arrow_left, 'Se déconnecter', isDestructive: true, onTap: _logout), // APPEL À _logout ICI
          ],
        ),
      ),
    );
  }

  Widget _infoTile(IconData icon, String label, String value) => ListTile(
        leading: Icon(icon, color: Color(0xFF2196F3), size: 22),
        title: Text(label, style: TextStyle(fontWeight: FontWeight.w500, fontSize: 14.5, color: Color(0xFF4B5563))),
        subtitle: Text(value, style: TextStyle(fontSize: 15, color: Color(0xFF1F2937), fontWeight: FontWeight.w600)),
        contentPadding: const EdgeInsets.symmetric(vertical: 4, horizontal: 0),
        dense: true,
      );

  Widget _activityTile(IconData icon, String title, String value, {String? subtitle}) => ListTile(
        leading: Icon(icon, color: Theme.of(context).primaryColor, size: 22),
        title: Text(title, style: TextStyle(fontWeight: FontWeight.w500, fontSize: 14.5, color: Color(0xFF4B5563))),
        subtitle: subtitle != null
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [Text(value, style: TextStyle(fontSize: 15, color: Color(0xFF1F2937), fontWeight: FontWeight.w600)), Text(subtitle, style: const TextStyle(fontSize: 12.5, color: Colors.grey))],
              )
            : Text(value, style: TextStyle(fontSize: 15, color: Color(0xFF1F2937), fontWeight: FontWeight.w600)),
        contentPadding: const EdgeInsets.symmetric(vertical: 4, horizontal: 0),
        dense: true,
      );

  Widget _settingsButton(IconData icon, String label, {bool isDestructive = false, required VoidCallback onTap}) => Material(
    color: Colors.transparent,
    child: InkWell(
      onTap: onTap, // UTILISE LE onTap PASSÉ EN PARAMÈTRE
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Icon(icon, color: isDestructive ? Colors.red.shade600 : Color(0xFF2196F3), size: 22),
            const SizedBox(width: 16),
            Expanded(child: Text(label, style: TextStyle(color: isDestructive ? Colors.red.shade600 : Color(0xFF374151) , fontWeight: FontWeight.w500, fontSize: 15))),
            if (!isDestructive) Icon(CupertinoIcons.chevron_forward, size: 18, color: Colors.grey.shade400),
          ],
        ),
      ),
    ),
  );
}
